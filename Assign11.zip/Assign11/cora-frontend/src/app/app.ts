import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent implements OnInit {
  title = 'Cora Graph Research Explorer';

  // --- Connection Status ---
  backendStatus: 'connected' | 'error' | 'checking' = 'checking';
  errorMessage: string = '';

  // --- Search Inputs ---
  searchPaperId: string = ''; // Used for both hierarchy and starting-point
  targetPaperId: string = ''; // Used for citation path
  
  // --- Results ---
  citationResult: string = '';
  hierarchyResult: string[] = [];
  queryResults: any[] = [];
  
  // --- Loading States ---
  loadingUnified: boolean = false;
  loadingQuery: boolean = false;

  // --- Miscellaneous Query ---
  customQuery: string = 'MATCH (p:Paper) RETURN p LIMIT 5';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.checkConnection();
  }

  checkConnection() {
    this.backendStatus = 'checking';
    this.http.get<any>('http://localhost:3000/api/status')
      .subscribe({
        next: () => {
          this.backendStatus = 'connected';
          this.errorMessage = '';
        },
        error: (err) => {
          this.backendStatus = 'error';
          const backendErr = err.error;
          this.errorMessage = backendErr?.message || "Could not connect to backend server.";
          if (backendErr?.hint) {
            this.errorMessage += ` (Hint: ${backendErr.hint})`;
          }
        }
      });
  }

  /**
   * One-Click Unified Search (4a + 4b)
   * Fetches hierarchy for searchPaperId and checks if it cites targetPaperId
   */
  unifiedSearch() {
    if (!this.searchPaperId) {
      alert("Please enter a Paper ID to investigate.");
      return;
    }

    this.loadingUnified = true;
    this.hierarchyResult = [];
    this.citationResult = '';
    this.errorMessage = '';

    // 1. Fetch Hierarchy (4b)
    this.http.get<any>(`http://localhost:3000/api/hierarchy?paperId=${this.searchPaperId}`)
      .subscribe({
        next: (data) => {
          this.hierarchyResult = data.path;
          if (this.hierarchyResult.length === 0) {
            this.errorMessage = "No hierarchy found for this Paper ID.";
          }
        },
        error: (err) => {
          this.errorMessage = "Error fetching hierarchy.";
        }
      });

    // 2. Fetch Citation Path (4a) - Only if target is provided
    if (this.targetPaperId) {
      this.http.get<any>(`http://localhost:3000/api/citation-path?idA=${this.searchPaperId}&idB=${this.targetPaperId}`)
        .subscribe({
          next: (data) => {
            this.citationResult = data.depth !== 'No Path' 
              ? `Connection Found! Citation Depth: ${data.depth}` 
              : 'No citation path exists between these papers.';
            this.loadingUnified = false;
          },
          error: (err) => {
            this.citationResult = "Error connecting to server for citation check.";
            this.loadingUnified = false;
          }
        });
    } else {
      // If no target, we're done after hierarchy (simulated delay for UX)
      setTimeout(() => this.loadingUnified = false, 500);
    }
  }

  /**
   * Miscellaneous Query Execution (4c)
   */
  runCustomQuery() {
    if (!this.customQuery) return;
    this.loadingQuery = true;
    this.queryResults = [];
    this.errorMessage = '';

    this.http.post<any>('http://localhost:3000/api/query', { cypher: this.customQuery })
      .subscribe({
        next: (data) => {
          this.queryResults = data.data;
          this.loadingQuery = false;
          if (this.queryResults.length === 0) {
            this.errorMessage = "Query executed but returned no results.";
          }
        },
        error: (err) => {
          this.errorMessage = "Query Error: " + (err.error?.error || err.message);
          this.loadingQuery = false;
        }
      });

    // Timeout safety
    setTimeout(() => {
        if (this.loadingQuery) {
            this.loadingQuery = false;
            this.errorMessage = 'Query timed out. Check your backend status.';
        }
    }, 15000);
  }

  formatResult(res: any): string {
    return JSON.stringify(res, null, 2);
  }
}