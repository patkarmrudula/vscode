const express = require('express');
const neo4j = require('neo4j-driver');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// 1. Connection Setup
const driver = neo4j.driver(
    'bolt://localhost:7687', 
    neo4j.auth.basic('neo4j', 'Mrudula@6'),
    { 
        connectionTimeout: 5000, 
        maxConnectionLifetime: 3 * 60 * 60 * 1000 
    }
);

// Helper to check connection status
app.get('/api/status', async (req, res) => {
    try {
        await driver.verifyConnectivity();
        res.json({ 
            status: 'connected', 
            message: 'Neo4j is reachable!',
            details: { uri: 'bolt://localhost:7687', user: 'neo4j' }
        });
    } catch (err) {
        console.error("Connectivity Error:", err.message);
        res.status(500).json({ 
            status: 'error', 
            message: err.message,
            code: err.code,
            hint: 'Ensure Neo4j Desktop is running and password is correct.'
        });
    }
});

// 2. Part 4a: Citation Connection Logic
app.get('/api/citation-path', async (req, res) => {
    const { idA, idB } = req.query;
    if (!idA || !idB) return res.status(400).json({ error: 'Missing Paper IDs' });
    
    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (a:Paper {id: $idA}), (b:Paper {id: $idB})
             MATCH path = shortestPath((a)-[:CITES*1..]->(b))
             RETURN length(path) as depth`, { idA, idB }
        );
        const depth = result.records[0]?.get('depth');
        res.json({ depth: depth !== undefined ? (neo4j.isInt(depth) ? neo4j.integer.toNumber(depth) : depth) : 'No Path' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    } finally {
        await session.close();
    }
});

// 3. Part 4b: Hierarchy Logic
app.get('/api/hierarchy', async (req, res) => {
    const { paperId } = req.query;
    if (!paperId) return res.status(400).json({ error: 'Missing Paper ID' });

    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (p:Paper {id: $paperId})-[:HAS_CATEGORY]->(leaf:Classification)
             MATCH path = (leaf)-[:SUB_CLASS_OF*0..]->(root)
             RETURN [n in nodes(path) | n.name] as hierarchy`, { paperId }
        );
        res.json({ path: result.records[0]?.get('hierarchy') ?? [] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    } finally {
        await session.close();
    }
});

// 4. Part 4c: Miscellaneous / User Defined Queries
app.post('/api/query', async (req, res) => {
    const { cypher } = req.body;
    if (!cypher) return res.status(400).json({ error: 'No Cypher query provided' });

    const session = driver.session();
    try {
        const result = await session.run(cypher);
        
        const data = result.records.map(record => {
            const row = {};
            record.forEach((value, key) => {
                // Safely handle Neo4j Integers
                if (neo4j.isInt(value)) {
                    row[key] = neo4j.integer.toNumber(value);
                } 
                // Handle Neo4j Nodes
                else if (typeof value === 'object' && value !== null && value.labels) {
                    const props = {};
                    for (let p in value.properties) {
                        props[p] = neo4j.isInt(value.properties[p]) ? neo4j.integer.toNumber(value.properties[p]) : value.properties[p];
                    }
                    row[key] = { labels: value.labels, properties: props };
                }
                else {
                    row[key] = value;
                }
            });
            return row;
        });
        
        res.json({ data });
    } catch (err) {
        console.error("Query Error:", err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await session.close();
    }
});

app.listen(3000, () => console.log('Backend running on http://localhost:3000'));