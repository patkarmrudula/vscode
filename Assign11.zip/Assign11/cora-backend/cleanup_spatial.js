const neo4j = require('neo4j-driver');

const driver = neo4j.driver(
    'bolt://localhost:7687', 
    neo4j.auth.basic('neo4j', 'Mrudula@6')
);

async function cleanup() {
    const session = driver.session();
    try {
        console.log("Starting deletion of 'Location' nodes...");
        const result = await session.run("MATCH (l:Location) DETACH DELETE l");
        console.log("Successfully deleted all Location nodes.");
    } catch (err) {
        console.error("Cleanup Error:", err.message);
    } finally {
        await session.close();
        await driver.close();
    }
}

cleanup();
