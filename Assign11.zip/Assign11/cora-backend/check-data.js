const neo4j = require('neo4j-driver');

const driver = neo4j.driver(
    'bolt://localhost:7687', 
    neo4j.auth.basic('neo4j', 'Mrudula@6')
);

async function checkData() {
    const session = driver.session();
    try {
        console.log("Checking for 'Paper' nodes...");
        const result = await session.run("MATCH (p:Paper) RETURN count(p) AS count");
        const count = result.records[0].get('count').toNumber();
        console.log(`Found ${count} Paper nodes.`);

        console.log("Checking for 'Location' nodes (Spatial)...");
        const locResult = await session.run("MATCH (l:Location) RETURN count(l) AS count");
        const locCount = locResult.records[0].get('count').toNumber();
        console.log(`Found ${locCount} Location nodes.`);

        if (count === 0 && locCount > 0) {
            console.log("WARNING: It looks like the Cora data is MISSING and only Spatial data exists.");
        } else if (count > 0 && locCount > 0) {
            console.log("NOTICE: Both Cora and Spatial data exist in the same database.");
        } else if (count === 0 && locCount === 0) {
            console.log("WARNING: Database is empty.");
        }

    } catch (err) {
        console.error("Error:", err.message);
    } finally {
        await session.close();
        await driver.close();
    }
}

checkData();
