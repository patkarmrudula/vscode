const neo4j = require('neo4j-driver');

const driver = neo4j.driver(
    'bolt://localhost:7687', 
    neo4j.auth.basic('neo4j', 'Mrudula@6'),
    { connectionTimeout: 5000 }
);

async function check() {
    console.log("Checking connection to bolt://localhost:7687...");
    try {
        await driver.verifyConnectivity();
        console.log("SUCCESS: Connected to Neo4j!");
        await driver.close();
        process.exit(0);
    } catch (err) {
        console.error("FAILURE: Could not connect to Neo4j.");
        console.error("Error Message:", err.message);
        console.error("Code:", err.code);
        await driver.close();
        process.exit(1);
    }
}

check();
