# Assignment 11: Cora Research Explorer - User Guide

This guide explains how to start the project and provides example inputs to verify each requirement.

## 🚀 How to Run

### Step 1: Start Neo4j
1. Open **Neo4j Desktop**.
2. Click **Start** on your database (where you imported the Cora CSVs).
3. Ensure the connection is green and active.

### Step 2: Run the Backend
1. Open a terminal in `Assignment11/cora-backend`.
2. Run the command:
   ```bash
   node server.js
   ```
3. You should see `Backend running on http://localhost:3000`.

### Step 3: Run the Frontend
1. Open a new terminal in `Assignment11/cora-frontend`.
2. Run the command:
   ```bash
   npm start
   ```
3. Once compiled, open your browser and visit:
   `http://localhost:4200`

---

## 🔍 Example Inputs (Test Data)

Use these IDs to verify the functionality:

### 📑 Paper Investigator (Unified Req 4a & 4b)
Enter these IDs to see the hierarchy and citation connections:
- **Search Paper ID**: `2`
- **Target Paper ID**: `16`
- **Result**: You should see the classification path (breadcrumb) and whether Paper 2 cites Paper 16.

**Other verified Paper IDs**: `18`, `35`, `1001`, `5456`.

### ⚡ Cypher Console (Req 4c)
Try running these custom queries:
- **Total Paper Count**:
  ```cypher
  MATCH (n:Paper) RETURN count(n) AS totalPapers
  ```
- **List Top Categories**:
  ```cypher
  MATCH (c:Classification) RETURN c.name LIMIT 10
  ```
- **Check Database Schema**:
  ```cypher
  CALL db.schema.visualization()
  ```

---

## ✅ Checklist for "Proper" Submission
- [x] **Database Status**: Top-right badge should be green.
- [x] **Unified Search**: Entering one ID and clicking "Analyze" fulfills bothReq 4a and 4b (if a target is provided).
- [x] **Errors**: If IDs don't exist, the UI will show a helpful error message instead of crashing.
