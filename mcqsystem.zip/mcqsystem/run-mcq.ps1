$BackendDir = "c:\Users\mahen\New folder\my-mcq-project\mcq-backend"
$FrontendDir = "c:\Users\mahen\New folder\my-mcq-project\mcq-frontend"

Write-Host "🚀 Starting MCQ Platform..." -ForegroundColor Cyan

Write-Host "📂 Starting Backend in new window..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$BackendDir'; npm start"

Write-Host "📂 Starting Frontend in CURRENT window..."
cd $FrontendDir
npm start
