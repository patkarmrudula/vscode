import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../data.service';
import { AuthService } from '../auth';

@Component({
    selector: 'app-questions',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './questions.html'
})
export class QuestionsComponent implements OnInit {
    questions: any[] = [];
    role = '';
    editingQuestionId: number | null = null;

    // Form model
    newQuestion = {
        content: '',
        image_url: '',
        options: [
            { option_text: '', is_correct: false },
            { option_text: '', is_correct: false },
            { option_text: '', is_correct: false },
            { option_text: '', is_correct: false }
        ]
    };

    showForm = false;

    constructor(private data: DataService, private auth: AuthService) {
        this.role = this.auth.getRole() || '';
    }

    ngOnInit() {
        this.loadQuestions();
    }

    loadQuestions() {
        this.data.getQuestions().subscribe({
            next: (res) => this.questions = res,
            error: (err) => console.error(err)
        });
    }

    toggleForm() {
        this.showForm = !this.showForm;
        if (!this.showForm) {
            this.resetForm();
        }
    }

    onEdit(question: any) {
        this.editingQuestionId = question.id;
        this.newQuestion = {
            content: question.content,
            image_url: question.image_url,
            options: question.options.map((o: any) => ({
                option_text: o.option_text,
                is_correct: o.is_correct
            }))
        };
        this.showForm = true;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    onDelete(id: number) {
        if (confirm('Are you sure you want to delete this question?')) {
            this.data.deleteQuestion(id).subscribe({
                next: () => {
                    this.loadQuestions();
                },
                error: (err) => alert('Failed to delete question')
            });
        }
    }

    onApprove(question: any) {
        const updated = { ...question, is_approved: true };
        this.data.updateQuestion(question.id, updated).subscribe({
            next: () => {
                this.loadQuestions();
            },
            error: (err) => alert('Failed to approve question')
        });
    }

    onSubmit() {
        if (this.editingQuestionId) {
            this.data.updateQuestion(this.editingQuestionId, this.newQuestion).subscribe({
                next: () => {
                    alert('Question updated successfully!');
                    this.showForm = false;
                    this.resetForm();
                    this.loadQuestions();
                },
                error: (err) => alert('Failed to update question')
            });
        } else {
            this.data.addQuestion(this.newQuestion).subscribe({
                next: () => {
                    alert('Question submitted successfully!');
                    this.showForm = false;
                    this.resetForm();
                    this.loadQuestions();
                },
                error: (err) => alert('Failed to submit question')
            });
        }
    }

    resetForm() {
        this.editingQuestionId = null;
        this.newQuestion = {
            content: '',
            image_url: '',
            options: [
                { option_text: '', is_correct: false },
                { option_text: '', is_correct: false },
                { option_text: '', is_correct: false },
                { option_text: '', is_correct: false }
            ]
        };
    }
}
