import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth';

@Injectable({
    providedIn: 'root'
})
export class DataService {
    private apiUrl = 'http://127.0.0.1:3000/api';

    constructor(private http: HttpClient, private auth: AuthService) { }

    private getHeaders() {
        return new HttpHeaders({
            'Authorization': `Bearer ${this.auth.getToken()}`
        });
    }

    getDashboardStats(): Observable<any> {
        return this.http.get(`${this.apiUrl}/results/stats`, { headers: this.getHeaders() });
    }

    getQuestions(): Observable<any> {
        return this.http.get(`${this.apiUrl}/questions`, { headers: this.getHeaders() });
    }

    addQuestion(question: any): Observable<any> {
        return this.http.post(`${this.apiUrl}/questions`, question, { headers: this.getHeaders() });
    }

    updateQuestion(id: number, question: any): Observable<any> {
        return this.http.put(`${this.apiUrl}/questions/${id}`, question, { headers: this.getHeaders() });
    }

    deleteQuestion(id: number): Observable<any> {
        return this.http.delete(`${this.apiUrl}/questions/${id}`, { headers: this.getHeaders() });
    }

    getExams(): Observable<any> {
        return this.http.get(`${this.apiUrl}/exams`, { headers: this.getHeaders() });
    }

    createExam(exam: any): Observable<any> {
        return this.http.post(`${this.apiUrl}/exams`, exam, { headers: this.getHeaders() });
    }

    getExamDetails(id: number): Observable<any> {
        return this.http.get(`${this.apiUrl}/exams/${id}`, { headers: this.getHeaders() });
    }

    startExam(examId: number): Observable<any> {
        return this.http.post(`${this.apiUrl}/results/start`, { exam_id: examId }, { headers: this.getHeaders() });
    }

    submitExam(examId: number, answers: any): Observable<any> {
        return this.http.post(`${this.apiUrl}/results/submit`, { exam_id: examId, answers }, { headers: this.getHeaders() });
    }

    getReportData(entity: string): Observable<any> {
        return this.http.get(`${this.apiUrl}/results/reports/${entity}`, { headers: this.getHeaders() });
    }
}
