import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { LayoutComponent } from './layout/layout';
import { DashboardComponent } from './dashboard/dashboard';
import { QuestionsComponent } from './questions/questions';
import { ExamsComponent } from './exams/exams';
import { AvailableExamsComponent } from './exams/available-exams';
import { ExamPortalComponent } from './exams/exam-portal';
import { ReportsComponent } from './reports/reports';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'questions', component: QuestionsComponent },
      { path: 'exams', component: ExamsComponent },
      { path: 'available-exams', component: AvailableExamsComponent },
      { path: 'exam-portal/:id', component: ExamPortalComponent },
      { path: 'reports', component: ReportsComponent },
      // Other routes will be added here
    ]
  },
  { path: '**', redirectTo: '' }
];
