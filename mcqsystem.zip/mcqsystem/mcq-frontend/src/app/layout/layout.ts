import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from '../sidebar/sidebar';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, SidebarComponent],
  template: `
    <div class="flex min-h-screen bg-slate-50" style="display: flex; min-height: 100vh; background-color: #f8fafc;">
      <app-sidebar></app-sidebar>
      <main class="ml-64 flex-1 p-8" style="margin-left: 16rem; flex: 1; padding: 2rem;">
        <div class="max-w-7xl mx-auto" style="max-width: 80rem; margin-left: auto; margin-right: auto;">
            <router-outlet></router-outlet>
        </div>
      </main>
    </div>
  `
})
export class LayoutComponent { }
