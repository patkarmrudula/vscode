import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../data.service';
import { AuthService } from '../auth';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6" style="padding-bottom: 2rem;">
      <header class="bg-white p-8 rounded-2xl shadow-sm border border-slate-100" style="background-color: white; padding: 2rem; border-radius: 1rem; border: 1px solid #f1f5f9;">
        <h1 class="text-3xl font-bold text-slate-800" style="color: #1e293b; font-family: sans-serif; margin: 0;">Welcome, {{ userName }}!</h1>
        <p class="text-slate-500 mt-2" style="color: #64748b; margin-top: 0.5rem;">Here's an overview of your MCQ performance and management.</p>
      </header>

      <div *ngIf="role === 'ADMIN'" class="grid grid-cols-1 md:grid-cols-3 gap-6" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-100" style="background-color: white; padding: 1.5rem; border-radius: 0.75rem; border: 1px solid #f1f5f9;">
          <h3 class="text-slate-500 text-sm font-medium uppercase tracking-wider" style="color: #64748b; font-size: 12px; font-weight: 600;">Total Students</h3>
          <p class="text-4xl font-bold text-slate-900 mt-4" style="color: #0f172a; font-size: 2.25rem; font-weight: 800; margin-top: 1rem;">{{ stats?.student_count || 0 }}</p>
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-100" *ngFor="let stat of stats?.exam_stats" style="background-color: white; padding: 1.5rem; border-radius: 0.75rem; border: 1px solid #f1f5f9;">
          <h3 class="text-slate-500 text-sm font-medium uppercase tracking-wider" style="color: #64748b; font-size: 12px; font-weight: 600;">{{ stat.status }} Exams</h3>
          <p class="text-4xl font-bold text-slate-900 mt-4" style="color: #0f172a; font-size: 2.25rem; font-weight: 800; margin-top: 1rem;">{{ stat.count || 0 }}</p>
        </div>
      </div>

    </div>
  `
})
export class DashboardComponent implements OnInit {
  userName = '';
  role = '';
  stats: any;

  constructor(private auth: AuthService, private data: DataService) {
    this.userName = this.auth.getUserName() || 'User';
    this.role = this.auth.getRole() || '';
  }

  ngOnInit() {
    if (this.role === 'ADMIN') {
      this.data.getDashboardStats().subscribe({
        next: (res) => this.stats = res,
        error: (err) => console.error(err)
      });
    }
  }
}
