import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth'; // This connects to your auth.ts file

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {
  // These variables hold the user input
  email = '';
  password = '';

  constructor(private auth: AuthService, private router: Router) { }

  onLogin() {
    console.log('Attempting login with:', this.email);

    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: (res) => {
        alert('Success! Welcome ' + res.fullname);
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        alert('Login failed. Please check your credentials.');
        console.error(err);
      }
    });
  }
}