import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-6" style="padding-bottom: 2rem;">
      <header class="flex justify-between items-center bg-white p-6 rounded-xl shadow-sm border border-slate-100" style="background-color: white; padding: 1.5rem; border-radius: 1rem; border: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h1 class="text-3xl font-bold text-slate-800" style="color: #1e293b; font-family: sans-serif; margin: 0;">Generic Reports</h1>
          <p class="text-slate-500 mt-1" style="color: #64748b;">Analyze and export platform data.</p>
        </div>
        <select [(ngModel)]="currentEntity" (ngModelChange)="loadData()" 
                style="padding: 10px 16px; border: 1px solid #e2e8f0; border-radius: 8px; background-color: white; outline: none; font-weight: 500; cursor: pointer; min-width: 200px;"
                class="p-3 border rounded-lg bg-white shadow-sm outline-none focus:ring-2 focus:ring-blue-500">
          <option value="userrrr">Users & Accounts</option>
          <option value="questions">Question Bank</option>
          <option value="exams">Exams & Configurations</option>
          <option value="exam_results">Student Submissions</option>
        </select>
      </header>

      <div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden overflow-x-auto" style="background-color: white; border-radius: 1rem; border: 1px solid #f1f5f9; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: auto;">
        <table class="w-full text-left" style="width: 100%; border-collapse: collapse;">
          <thead class="bg-slate-50 border-b border-slate-100" style="background-color: #f8fafc; border-bottom: 1px solid #e2e8f0;">
            <tr>
              <th *ngFor="let col of columns" class="px-6 py-4 text-sm font-semibold text-slate-600 uppercase tracking-wider" style="padding: 16px; font-weight: 600; color: #475569; font-size: 12px; text-transform: uppercase;">
                {{ col.replace('_', ' ') }}
              </th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100">
            <tr *ngFor="let row of dataList" class="hover:bg-slate-50 transitioning" style="border-bottom: 1px solid #f1f5f9;">
              <td *ngFor="let col of columns" class="px-6 py-4 text-sm text-slate-600" style="padding: 16px; color: #334155; font-size: 14px;">
                {{ formatValue(row[col]) }}
              </td>
            </tr>
            <tr *ngIf="dataList.length === 0">
              <td [attr.colspan]="columns.length" class="px-6 py-12 text-center text-slate-400" style="padding: 3rem; text-align: center; color: #94a3b8;">
                No data entries found for this category.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class ReportsComponent implements OnInit {
  currentEntity = 'userrrr';
  dataList: any[] = [];
  columns: string[] = [];

  constructor(private data: DataService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.data.getReportData(this.currentEntity).subscribe({
      next: (res) => {
        this.dataList = res;
        if (res.length > 0) {
          this.columns = Object.keys(res[0]);
        } else {
          this.columns = [];
        }
      },
      error: (err) => console.error(err)
    });
  }

  formatValue(val: any): string {
    if (val === true) return 'YES';
    if (val === false) return 'NO';
    if (val === null || val === undefined) return '-';
    if (typeof val === 'string' && val.includes('T') && val.length > 15) {
      return new Date(val).toLocaleString();
    }
    return val;
  }
}
