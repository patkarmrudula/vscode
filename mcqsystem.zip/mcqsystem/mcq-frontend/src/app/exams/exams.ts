import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
    selector: 'app-exams',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './exams.html'
})
export class ExamsComponent implements OnInit {
    exams: any[] = [];
    questions: any[] = [];
    showForm = false;
    selectedExam: any = null;

    newExam = {
        title: '',
        fixed_start_time: '',
        duration_minutes: 60,
        question_ids: [] as number[]
    };

    constructor(private data: DataService) { }

    ngOnInit() {
        this.loadExams();
        this.loadQuestions();
    }

    loadExams() {
        this.data.getExams().subscribe({
            next: (res) => this.exams = res,
            error: (err) => console.error(err)
        });
    }

    loadQuestions() {
        this.data.getQuestions().subscribe({
            next: (res) => {
                // Only allow approved questions for exams
                this.questions = res.filter((q: any) => q.is_approved);
            },
            error: (err) => console.error(err)
        });
    }

    toggleQuestion(id: number) {
        const index = this.newExam.question_ids.indexOf(id);
        if (index > -1) {
            this.newExam.question_ids.splice(index, 1);
        } else {
            this.newExam.question_ids.push(id);
        }
    }

    viewDetails(exam: any) {
        this.data.getExamDetails(exam.id).subscribe({
            next: (res) => this.selectedExam = res,
            error: (err) => alert('Failed to load exam details')
        });
    }

    onSubmit() {
        if (this.newExam.question_ids.length === 0) {
            alert('Please select at least one question');
            return;
        }
        this.data.createExam(this.newExam).subscribe({
            next: () => {
                alert('Exam created successfully');
                this.showForm = false;
                this.resetForm();
                this.loadExams();
            },
            error: (err) => alert('Failed to create exam')
        });
    }

    resetForm() {
        this.newExam = {
            title: '',
            fixed_start_time: '',
            duration_minutes: 60,
            question_ids: []
        };
    }
}
