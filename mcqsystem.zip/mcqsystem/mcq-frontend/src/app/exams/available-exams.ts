import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-available-exams',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6" style="padding-bottom: 2rem;">
      <header class="bg-white p-8 rounded-2xl shadow-sm border border-slate-100" style="background-color: white; padding: 2rem; border-radius: 1rem; border: 1px solid #f1f5f9;">
        <h1 class="text-3xl font-bold text-slate-800" style="color: #1e293b; font-family: sans-serif; margin: 0;">Available Exams</h1>
        <p class="text-slate-500 mt-2" style="color: #64748b; margin-top: 0.5rem;">Select an exam to begin. Be sure to manage your time effectively!</p>
      </header>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
        <div *ngFor="let exam of exams" 
             style="background-color: white; padding: 1.5rem; border-radius: 1rem; border: 1px solid #f1f5f9; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; flex-direction: column;"
             class="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col hover:shadow-md transitioning">
          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <h3 class="text-xl font-bold text-slate-800" style="color: #1e293b; margin: 0;">{{ exam.title }}</h3>
            <span style="background-color: #f1f5f9; color: #475569; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600;">{{ exam.duration_minutes }}m</span>
          </div>
          <div class="mt-6 space-y-3 text-sm text-slate-500 flex-1" style="margin-top: 1.5rem; flex: 1; display: flex; flex-direction: column; gap: 8px;">
            <p><span style="color: #475569; font-weight: 600;">Type:</span> {{ exam.fixed_start_time ? 'Scheduled' : 'Practice / Anytime' }}</p>
            <p *ngIf="exam.fixed_start_time"><span style="color: #475569; font-weight: 600;">Starts:</span> {{ exam.fixed_start_time | date:'medium' }}</p>
            <p><span style="color: #475569; font-weight: 600;">Total Questions:</span> {{ exam.questions?.length || '?' }}</p>
          </div>
          <button (click)="startExam(exam.id)" 
                  style="width: 100%; background-color: #2563eb; color: white; padding: 12px; border-radius: 8px; border: none; font-weight: 700; cursor: pointer; margin-top: 1.5rem;"
                  class="w-full bg-blue-600 text-white font-bold p-3 rounded-lg mt-6 hover:bg-blue-700 transition">
            Start Exam Now
          </button>
        </div>
        
        <div *ngIf="exams.length === 0" 
             style="grid-column: 1 / -1; padding: 4rem 1rem; text-align: center; border: 2px dashed #e2e8f0; border-radius: 1rem; color: #64748b;"
             class="col-span-full py-12 text-center text-slate-500 bg-white rounded-xl border border-dashed">
          <p style="font-size: 1.125rem;">No exams are currently available for you.</p>
          <p style="font-size: 0.875rem;">Check back later or contact your instructor.</p>
        </div>
      </div>
    </div>
  `
})
export class AvailableExamsComponent implements OnInit {
  exams: any[] = [];

  constructor(private data: DataService, private router: Router) { }

  ngOnInit() {
    this.data.getExams().subscribe({
      next: (res) => this.exams = res,
      error: (err) => console.error(err)
    });
  }

  startExam(id: number) {
    if (confirm('Ready to start? The timer will begin immediately once you enter.')) {
      this.data.startExam(id).subscribe({
        next: () => this.router.navigate(['/exam-portal', id]),
        error: (err) => {
          if (err.status === 400 && err.error.data) {
            if (err.error.data.status === 'ongoing') {
              this.router.navigate(['/exam-portal', id]);
            } else {
              alert('You have already completed this exam.');
            }
          } else {
            alert('Could not start exam. It may be outside its scheduled window.');
          }
        }
      });
    }
  }
}
