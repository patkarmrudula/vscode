import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
    selector: 'app-exam-portal',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './exam-portal.html'
})
export class ExamPortalComponent implements OnInit, OnDestroy {
    exam: any;
    questions: any[] = [];
    currentQuestionIndex = 0;
    answers: { [key: number]: number } = {};
    timeLeft = 0;
    timerInterval: any;
    isCompleted = false;
    score = 0;

    constructor(
        private route: ActivatedRoute,
        private data: DataService,
        private router: Router
    ) { }

    ngOnInit() {
        const id = Number(this.route.snapshot.paramMap.get('id'));
        this.loadExam(id);
    }

    ngOnDestroy() {
        if (this.timerInterval) clearInterval(this.timerInterval);
    }

    loadExam(id: number) {
        this.data.getExamDetails(id).subscribe({
            next: (res) => {
                this.exam = res;
                this.questions = res.questions;
                this.timeLeft = res.duration_minutes * 60;
                this.startTimer();
            },
            error: (err) => {
                alert('Could not load exam details');
                this.router.navigate(['/available-exams']);
            }
        });
    }

    startTimer() {
        if (this.timerInterval) clearInterval(this.timerInterval);
        this.timerInterval = setInterval(() => {
            if (this.timeLeft > 0) {
                this.timeLeft--;
            } else {
                this.submitExam();
            }
        }, 1000);
    }

    get formatTime() {
        const min = Math.floor(this.timeLeft / 60);
        const sec = this.timeLeft % 60;
        return `${min}:${sec < 10 ? '0' : ''}${sec}`;
    }

    nextQuestion() {
        if (this.currentQuestionIndex < this.questions.length - 1) {
            this.currentQuestionIndex++;
        }
    }

    prevQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
        }
    }

    selectOption(qId: number, oId: number) {
        this.answers[qId] = oId;
    }

    submitExam() {
        if (confirm('Are you sure you want to submit your answers?')) {
            this.performSubmission();
        }
    }

    performSubmission() {
        if (this.timerInterval) clearInterval(this.timerInterval);
        this.data.submitExam(this.exam.id, this.answers).subscribe({
            next: (res) => {
                this.isCompleted = true;
                this.score = res.score;
                window.scrollTo({ top: 0, behavior: 'smooth' });
            },
            error: (err) => alert('Error submitting exam. Please check your connection.')
        });
    }
}
