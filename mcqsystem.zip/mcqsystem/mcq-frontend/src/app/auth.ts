import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Points to Node.js server using IP to avoid localhost resolution issues
  private apiUrl = 'http://127.0.0.1:3000/api/auth';

  constructor(private http: HttpClient, private router: Router) { }

  login(credentials: any): Observable<any> {
    console.log('Sending login request to:', `${this.apiUrl}/login`);
    console.log('Credentials:', credentials);
    return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
      tap({
        next: (res: any) => {
          console.log('Login success data:', res);
          localStorage.setItem('token', res.token);
          localStorage.setItem('role', res.role);
          localStorage.setItem('fullname', res.fullname);
        },
        error: (err) => console.error('Login error details:', err)
      })
    );
  }

  register(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, userData);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/']);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  getRole() {
    return localStorage.getItem('role');
  }

  getUserName() {
    return localStorage.getItem('fullname');
  }

  isLoggedIn() {
    return !!this.getToken();
  }
}