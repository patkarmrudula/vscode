import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../auth';

@Component({
    selector: 'app-sidebar',
    standalone: true,
    imports: [CommonModule, RouterModule],
    templateUrl: './sidebar.html',
    styleUrl: './sidebar.css'
})
export class SidebarComponent {
    role: string | null = '';
    userName: string | null = '';

    constructor(private auth: AuthService) {
        this.role = this.auth.getRole();
        this.userName = this.auth.getUserName();
    }

    onLogout() {
        this.auth.logout();
    }
}
