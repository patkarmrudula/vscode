const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const questionRoutes = require('./routes/questions');
const examRoutes = require('./routes/exams');
const resultRoutes = require('./routes/results');

const app = express();
app.use(cors());
app.use(express.json());

// Global logger to see ANY request
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/exams', examRoutes);
app.use('/api/results', resultRoutes);

const PORT = 3000;
const HOST = '0.0.0.0'; // Listen on all interfaces

app.listen(PORT, HOST, async () => {
    console.log(`🚀 Server running on http://${HOST}:${PORT}`);
    try {
        const pool = require('./db');
        const res = await pool.query('SELECT COUNT(*) FROM userrrr');
        console.log(`📊 DB User count: ${res.rows[0].count}`);
    } catch (e) {
        console.error('❌ DB Check Error:', e.message);
    }
});