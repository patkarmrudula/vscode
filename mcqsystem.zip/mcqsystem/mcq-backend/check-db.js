const pool = require('./db');
pool.query('SELECT * FROM userrrr', (err, res) => {
    if (err) {
        console.error('Error fetching users:', err.stack);
    } else {
        console.log('Users in database:', res.rows);
    }
    process.exit();
});
