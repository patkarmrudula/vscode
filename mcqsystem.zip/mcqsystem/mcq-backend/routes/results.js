const express = require('express');
const router = express.Router();
const pool = require('../db');
const { authenticate, authorize } = require('../middleware/auth');

// Start an exam (Create a record in exam_results)
router.post('/start', authenticate, async (req, res) => {
    const { exam_id } = req.body;
    try {
        // Check if student already has an ongoing or completed exam
        const existing = await pool.query(
            'SELECT * FROM exam_results WHERE student_id = $1 AND exam_id = $2',
            [req.user.id, exam_id]
        );
        if (existing.rows.length > 0) {
            return res.status(400).json({ message: "Exam already started or completed", data: existing.rows[0] });
        }

        const newResult = await pool.query(
            'INSERT INTO exam_results (student_id, exam_id, status) VALUES ($1, $2, $3) RETURNING *',
            [req.user.id, exam_id, 'ongoing']
        );
        res.json(newResult.rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// Submit answers and calculate score
router.post('/submit', authenticate, async (req, res) => {
    const { exam_id, answers } = req.body; // answers: { [questionId]: optionId }
    try {
        const resultRecord = await pool.query(
            'SELECT * FROM exam_results WHERE student_id = $1 AND exam_id = $2 AND status = $3',
            [req.user.id, exam_id, 'ongoing']
        );
        if (resultRecord.rows.length === 0) return res.status(404).json({ message: "Ongoing exam record not found" });

        // Calculate score
        let score = 0;
        const questions = await pool.query(
            `SELECT q.id, o.id as correct_option_id FROM questions q 
             JOIN options o ON q.id = o.question_id 
             JOIN exam_questions eq ON q.id = eq.question_id 
             WHERE eq.exam_id = $1 AND o.is_correct = TRUE`,
            [exam_id]
        );

        for (let q of questions.rows) {
            if (answers[q.id] == q.correct_option_id) {
                score++;
            }
        }

        // Update record
        const updatedResult = await pool.query(
            'UPDATE exam_results SET end_at = CURRENT_TIMESTAMP, status = $1, score = $2 WHERE id = $3 RETURNING *',
            ['completed', score, resultRecord.rows[0].id]
        );

        res.json(updatedResult.rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// GET Dashboard stats (Admin only)
router.get('/stats', authenticate, authorize(['ADMIN']), async (req, res) => {
    try {
        const stats = await pool.query(
            `SELECT status, COUNT(*) FROM exam_results GROUP BY status`
        );
        const studentCount = await pool.query('SELECT COUNT(*) FROM userrrr WHERE role = $1', ['STUDENT']);

        res.json({
            exam_stats: stats.rows,
            student_count: studentCount.rows[0].count
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// GET Generic Report Data (Admin only - Can list anything)
router.get('/reports/:entity', authenticate, authorize(['ADMIN']), async (req, res) => {
    const { entity } = req.params;
    const allowedEntities = ['userrrr', 'questions', 'exams', 'exam_results'];
    if (!allowedEntities.includes(entity)) return res.status(400).json({ message: "Invalid entity" });

    try {
        const result = await pool.query(`SELECT * FROM ${entity} ORDER BY id DESC`);
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

module.exports = router;
