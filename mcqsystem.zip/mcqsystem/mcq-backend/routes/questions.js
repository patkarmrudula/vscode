const express = require('express');
const router = express.Router();
const pool = require('../db');
const { authenticate, authorize } = require('../middleware/auth');

// GET all questions (Admin can see all, TA can see all?, Student maybe only approved?)
router.get('/', authenticate, async (req, res) => {
    try {
        let result;
        if (req.user.role === 'ADMIN' || req.user.role === 'TA') {
            result = await pool.query('SELECT * FROM questions ORDER BY id DESC');
        } else {
            result = await pool.query('SELECT * FROM questions WHERE is_approved = TRUE');
        }

        // Fetch options for each question
        const questions = result.rows;
        for (let q of questions) {
            const options = await pool.query('SELECT * FROM options WHERE question_id = $1', [q.id]);
            q.options = options.rows;
        }

        res.json(questions);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// POST new question (TA or Admin)
router.post('/', authenticate, authorize(['ADMIN', 'TA']), async (req, res) => {
    const { content, image_url, options } = req.body;
    const is_approved = req.user.role === 'ADMIN'; // Auto-approve if Admin
    try {
        const newQuestion = await pool.query(
            'INSERT INTO questions (content, image_url, created_by, is_approved) VALUES ($1, $2, $3, $4) RETURNING *',
            [content, image_url, req.user.id, is_approved]
        );
        const questionId = newQuestion.rows[0].id;

        // Insert options
        for (let opt of options) {
            await pool.query(
                'INSERT INTO options (question_id, option_text, is_correct) VALUES ($1, $2, $3)',
                [questionId, opt.option_text, opt.is_correct]
            );
        }

        res.json({ ...newQuestion.rows[0], options });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// PUT update/approve question (Admin only for approval, TA maybe for edit if not approved?)
router.put('/:id', authenticate, authorize(['ADMIN', 'TA']), async (req, res) => {
    const { id } = req.params;
    const { content, image_url, is_approved, options } = req.body;
    try {
        // Admin can do anything, TA might only be able to edit if not approved
        if (req.user.role === 'TA') {
            const check = await pool.query('SELECT is_approved FROM questions WHERE id = $1', [id]);
            if (check.rows[0].is_approved) {
                return res.status(403).json({ message: "Cannot edit an approved question" });
            }
        }

        const updateQuestion = await pool.query(
            'UPDATE questions SET content = $1, image_url = $2, is_approved = $3 WHERE id = $4 RETURNING *',
            [content, image_url, is_approved, id]
        );

        if (options) {
            // Simple replace strategy for options
            await pool.query('DELETE FROM options WHERE question_id = $1', [id]);
            for (let opt of options) {
                await pool.query(
                    'INSERT INTO options (question_id, option_text, is_correct) VALUES ($1, $2, $3)',
                    [id, opt.option_text, opt.is_correct]
                );
            }
        }

        res.json({ ...updateQuestion.rows[0], options });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// DELETE question (Admin only)
router.delete('/:id', authenticate, authorize(['ADMIN']), async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM questions WHERE id = $1', [id]);
        res.json({ message: "Question deleted successfully" });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

module.exports = router;
