const express = require('express');
const router = express.Router();
const pool = require('../db');
const { authenticate, authorize } = require('../middleware/auth');

// GET all exams
router.get('/', authenticate, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM exams ORDER BY id DESC');
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// POST new exam (Admin only)
router.post('/', authenticate, authorize(['ADMIN']), async (req, res) => {
    const { title, fixed_start_time, duration_minutes, question_ids } = req.body;
    try {
        // Create the exam
        const newExam = await pool.query(
            'INSERT INTO exams (title, fixed_start_time, duration_minutes, created_by) VALUES ($1, $2, $3, $4) RETURNING *',
            [title, fixed_start_time, duration_minutes, req.user.id]
        );
        const examId = newExam.rows[0].id;

        // Map questions to the exam
        if (question_ids && question_ids.length > 0) {
            for (let qId of question_ids) {
                await pool.query(
                    'INSERT INTO exam_questions (exam_id, question_id) VALUES ($1, $2)',
                    [examId, qId]
                );
            }
        }

        res.json({ ...newExam.rows[0], question_ids });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// GET exam details with questions
router.get('/:id', authenticate, async (req, res) => {
    const { id } = req.params;
    try {
        const exam = await pool.query('SELECT * FROM exams WHERE id = $1', [id]);
        if (exam.rows.length === 0) return res.status(404).json({ message: "Exam not found" });

        const questionsResult = await pool.query(
            `SELECT q.* FROM questions q 
             JOIN exam_questions eq ON q.id = eq.question_id 
             WHERE eq.exam_id = $1`,
            [id]
        );

        const questions = questionsResult.rows;
        for (let q of questions) {
            const options = await pool.query('SELECT id, option_text FROM options WHERE question_id = $1', [q.id]);
            q.options = options.rows;
        }

        res.json({ ...exam.rows[0], questions });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

module.exports = router;
