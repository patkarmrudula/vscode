const express = require('express');
const router = express.Router();
const pool = require('../db');
const jwt = require('jsonwebtoken');

// Register (for testing or students)
router.post('/register', async (req, res) => {
    const { fullname, email, password, role } = req.body;
    try {
        const newUser = await pool.query(
            'INSERT INTO userrrr (fullname, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING *',
            [fullname, email, password, role || 'STUDENT']
        );
        res.json(newUser.rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// Login
router.post('/login', async (req, res) => {
    let { email, password } = req.body;
    if (email) email = email.trim();
    console.log(`Login attempt for: ${email}`);
    try {
        const user = await pool.query('SELECT * FROM userrrr WHERE email = $1', [email]);
        console.log(`User found: ${user.rows.length > 0}`);

        if (user.rows.length === 0 || user.rows[0].password_hash !== password) {
            console.log('Invalid credentials or user not found');
            return res.status(401).json({ message: "Invalid credentials" });
        }

        const userData = user.rows[0];
        const token = jwt.sign(
            { id: userData.id, role: userData.role, fullname: userData.fullname },
            process.env.JWT_SECRET,
            { expiresIn: '5h' }
        );

        res.json({
            token,
            role: userData.role,
            fullname: userData.fullname
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

module.exports = router;
