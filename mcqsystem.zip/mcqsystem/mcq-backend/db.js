const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// A small test to confirm it works
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Connection Error:', err.stack);
  } else {
    console.log('✅ Connected to mcq_platform_final at:', res.rows[0].now);
  }
});

module.exports = pool;