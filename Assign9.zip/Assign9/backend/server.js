const express = require('express');
const mongoose = require('mongoose');
const cassandra = require('cassandra-driver');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// A] MongoDB Connection (using your PRN)
// A] MongoDB Connection (using your PRN)
mongoose.connect('mongodb://127.0.0.1:27017/db_23510082')
    .then(() => console.log("✅ MongoDB Connected Successfully"))
    .catch(err => {
        console.error("❌ MongoDB Connection Error:", err.message);
        process.exit(1); // Exit if DB connection fails
    });

// Define a single Student schema/model outside the route
const StudentSchema = new mongoose.Schema({ name: String, prn: String });
const Student = mongoose.model('Student', StudentSchema);

// B] Cassandra Connection
const cassClient = new cassandra.Client({ 
    contactPoints: ['127.0.0.1'], 
    localDataCenter: 'datacenter1' 
});

cassClient.connect()
    .then(() => console.log("✅ Cassandra Connected Successfully"))
    .catch(err => {
        console.error("❌ Cassandra Connection Error:", err.message);
        // Don't exit here, we might want to see if Mongo works
    });

// CRUD - CREATE Route
app.post('/add-student', async (req, res) => {
    const { name, prn } = req.body;
    console.log(`Attempting to save: ${name} with PRN: ${prn}`);

    try {
        // 1. Save to MongoDB
        console.log("Saving to MongoDB...");
        const newStudent = new Student({ name, prn });
        await newStudent.save();
        console.log("✅ Saved to MongoDB");

        // 2. Save to Cassandra
        console.log("Saving to Cassandra...");
        const query = 'INSERT INTO ks_23510082.users (id, name, prn) VALUES (uuid(), ?, ?)';
        await cassClient.execute(query, [name, prn], { prepare: true });
        console.log("✅ Saved to Cassandra");

        // 3. SEND RESPONSE
        return res.status(200).json({ 
            message: "Success: Data saved to both databases!" 
        });

    } catch (error) {
        console.error("❌ Database Operation Error:", error);
        return res.status(500).json({ 
            error: "Failed to save data. " + error.message 
        });
    }
});

// CRITICAL: This was missing! This actually starts your server.
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});