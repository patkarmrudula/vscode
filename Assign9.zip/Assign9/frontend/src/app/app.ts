import { Component, signal } from '@angular/core'; // 1. Import 'signal'
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule],
  template: `
    <div style="max-width: 400px; margin: 50px auto; border: 1px solid #ccc; padding: 20px; border-radius: 8px; font-family: sans-serif; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
      <h2 style="text-align: center; color: #333;">Assignment 9: CRUD</h2>
      
      <div style="margin-bottom: 15px;">
        <label>Student Name:</label>
        <input [(ngModel)]="studentData.name" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
      </div>
      
      <div style="margin-bottom: 15px;">
        <label>PRN:</label>
        <input [(ngModel)]="studentData.prn" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
      </div>

      <button (click)="submit()" style="width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">
        Submit to Databases
      </button>

      <div *ngIf="status()" [style.color]="status().includes('Error') ? 'red' : 'green'" style="margin-top: 15px; font-weight: bold; text-align: center;">
        {{ status() }}
      </div>
    </div>
  `
})
export class AppComponent {
  studentData = { name: '', prn: '' };
  
  // 3. Define status as a signal
  status = signal('');

  constructor(private dataService: DataService) {}

  submit() {
    if(!this.studentData.name || !this.studentData.prn) {
        this.status.set("Error: Please fill both fields");
        return;
    }

    this.status.set("Sending data...");
    
    this.dataService.postStudent(this.studentData).subscribe({
      next: (res: any) => {
        console.log("Response received:", res);
        this.status.set("Success: " + res.message);
        this.studentData = { name: '', prn: '' };
      },
      error: (err: any) => {
        console.error("HTTP Error:", err);
        const errorMsg = err.error?.error || "Connection Failed (Is the backend running?)";
        this.status.set("Error: " + errorMsg);
      }
    });
  }
}