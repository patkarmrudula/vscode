import http from 'k6/http';
import { check } from 'k6';

const BASE_URL = 'http://localhost:3000/api';

export default function () {

  // LOGIN
  let loginRes = http.post(`${BASE_URL}/auth/login`, JSON.stringify({
    username: 'admin',        // change if needed
    password: 'admin123'  // change if needed
  }), {
    headers: { 'Content-Type': 'application/json' },
  });

  console.log("Login status:", loginRes.status);

  if (loginRes.status !== 200) {
    console.log("Login body:", loginRes.body);
    return;
  }

  let token = loginRes.json('token');

  // FETCH STUDENTS
  let studentRes = http.get(`${BASE_URL}/students`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  console.log("Students status:", studentRes.status);
  console.log("Students body:", studentRes.body);

  check(studentRes, {
    'students fetched': (r) => r.status === 200,
  })}