// MONGO DB Code



const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv').config();

const studentRoutes = require('./routes/students');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
  origin: 'http://localhost:4200'
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/23510043')
  .then(() => {
    console.log('✅ MongoDB Connected to 23510043 database');
  })
  .catch((err) => {
    console.error('❌ MongoDB Connection Error:', err);
  });

// Routes
app.use('/api/students', studentRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Student Management Backend Running' });
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
});





//      CASSANDRA CODE


// const express = require('express');
// const cassandra = require('cassandra-driver');
// const cors = require('cors');

// const app = express();
// const port = 3000;

// // Middleware
// app.use(cors());
// app.use(express.json());

// // Cassandra Connection Configuration
// // '23510043' हा तुझा Keyspace नाव आहे
// const client = new cassandra.Client({
//     contactPoints: ['127.0.0.1'],
//     localDataCenter: 'datacenter1',
//     keyspace: '23510043'
// });

// // Connect to Cassandra
// client.connect()
//     .then(() => console.log('Connected to Cassandra!'))
//     .catch(err => console.error('Cassandra connection error:', err));

// // API to Insert Student Data
// app.post('/api/students', (req, res) => {
//     const { name, rollNumber } = req.body;

//     // Cassandra मध्ये Primary Key (id) साठी UUID जनरेट करणे
//     const id = cassandra.types.Uuid.random();

//     const query = 'INSERT INTO students (id, name, rollNumber) VALUES (?, ?, ?)';
//     const params = [id, name, rollNumber];

//     client.execute(query, params, { prepare: true })
//         .then(result => {
//             console.log('Data inserted for:', name);
//             res.status(201).send({ 
//                 message: 'Data inserted successfully!', 
//                 insertedId: id 
//             });
//         })
//         .catch(err => {
//             console.error('Execution error:', err);
//             res.status(500).send({ error: err.message });
//         });
// });

// // API to Get All Students (Optional - for testing)
// app.get('/api/students', (req, res) => {
//     const query = 'SELECT * FROM students';
//     client.execute(query)
//         .then(result => res.send(result.rows))
//         .catch(err => res.status(500).send(err));
// });

// app.listen(port, () => {
//     console.log(`Server running on port ${port}`);
// });