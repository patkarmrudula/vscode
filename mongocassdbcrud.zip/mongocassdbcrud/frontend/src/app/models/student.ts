export interface Student {
  _id?: string;
  name: string;
  rollNumber: string;
  department: string;
  createdAt?: string;
  updatedAt?: string;
}

