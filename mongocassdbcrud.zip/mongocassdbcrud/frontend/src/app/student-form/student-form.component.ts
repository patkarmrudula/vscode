import { Component, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Student } from '../models/student';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {
  private studentService = inject(StudentService);
  private fb = inject(FormBuilder);

  students = signal<Student[]>([]);
  selectedStudent = signal<Student | null>(null);
  isEditMode = signal(false);
  studentForm: FormGroup;

  constructor() {
    this.studentForm = this.fb.group({
      name: ['', Validators.required],
      rollNumber: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9]+$/)]],
      department: ['', Validators.required]
    });

    effect(() => {
      this.loadStudents();
    });
  }

  loadStudents() {
    this.studentService.getStudents().subscribe({
      next: (students) => this.students.set(students),
      error: (err) => console.error('Error loading students', err)
    });
  }

  onSubmit() {
    if (this.studentForm.invalid) {
      this.studentForm.markAllAsTouched();
      return;
    }

    const formValue = this.studentForm.value;

    if (this.isEditMode()) {
      if (this.selectedStudent()) {
        this.studentService.updateStudent(this.selectedStudent()!._id!, formValue)
          .subscribe({
            next: () => {
              this.resetForm();
              this.loadStudents();
            },
            error: (err) => console.error('Update error', err)
          });
      }
    } else {
      this.studentService.createStudent(formValue)
        .subscribe({
          next: () => {
            this.resetForm();
            this.loadStudents();
          },
          error: (err) => console.error('Create error', err)
        });
    }
  }

  editStudent(student: Student) {
    this.selectedStudent.set(student);
    this.isEditMode.set(true);
    this.studentForm.patchValue(student);
  }

  deleteStudent(id: string) {
    if (confirm('Are you sure you want to delete this student?')) {
      this.studentService.deleteStudent(id).subscribe({
        next: () => this.loadStudents(),
        error: (err) => console.error('Delete error', err)
      });
    }
  }

  resetForm() {
    this.studentForm.reset();
    this.selectedStudent.set(null);
    this.isEditMode.set(false);
  }
}

