import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
}

export interface AuthResponse {
  message: string;
  token: string;
  user: User;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrl;
  private loggedInSubject = new BehaviorSubject<boolean>(this.hasToken());
  
  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  /**
   * Check if token exists in localStorage
   */
  private hasToken(): boolean {
    return !!localStorage.getItem('token');
  }

  /**
   * Get JWT token from localStorage
   */
  getToken(): string | null {
    return localStorage.getItem('token');
  }

  /**
   * Get current logged in status
   */
  isLoggedIn(): boolean {
    return this.loggedInSubject.value;
  }

  /**
   * Get logged in status as Observable
   */
  getLoggedIn(): Observable<boolean> {
    return this.loggedInSubject.asObservable();
  }

  /**
   * Get current user from localStorage
   */
  getUser(): User | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  /**
   * Get current user role
   */
  getUserRole(): string {
    const user = this.getUser();
    return user ? user.role : '';
  }

  /**
   * Check if user is admin
   */
  isAdmin(): boolean {
    return this.getUserRole() === 'admin';
  }

  /**
   * Check if user is staff
   */
  isStaff(): boolean {
    return this.getUserRole() === 'staff';
  }

  /**
   * Check if user is regular user
   */
  isUser(): boolean {
    return this.getUserRole() === 'user';
  }

  /**
   * Login user
   */
  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/auth/login`, {
      email,
      password
    });
  }

  /**
   * Signup user
   */
  signup(name: string, email: string, password: string, role: string = 'user'): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/auth/signup`, {
      name,
      email,
      password,
      role
    });
  }

  /**
   * Create staff user (Admin only)
   */
  createStaff(name: string, email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/auth/create-staff`, {
      name,
      email,
      password
    });
  }

  /**
   * Store token and user in localStorage
   */
  storeAuth(token: string, user: User): void {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    this.loggedInSubject.next(true);
  }

/**
   * Logout user and clear localStorage
   */
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.loggedInSubject.next(false);
    this.router.navigate(['/login']);
  }
}
