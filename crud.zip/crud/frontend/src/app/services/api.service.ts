import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

// Category interface
export interface Category {
  id: number;
  name: string;
  created_at?: string;
}

// Item interface
export interface Item {
  id: number;
  name: string;
  category_id: number;
  category_name?: string;
  created_at?: string;
}

// Enrollment interface
export interface Enrollment {
  id: number;
  user_id: number;
  item_id: number;
  item_name?: string;
  category_name?: string;
  created_at?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // ==================== Categories ====================
  
  /**
   * Get all categories
   */
  getCategories(): Observable<{ categories: Category[] }> {
    return this.http.get<{ categories: Category[] }>(`${this.apiUrl}/categories`);
  }

  /**
   * Create category (Admin only)
   */
  createCategory(name: string): Observable<{ message: string; category: Category }> {
    return this.http.post<{ message: string; category: Category }>(`${this.apiUrl}/categories`, { name });
  }

/**
   * Delete category (Admin only)
   */
  deleteCategory(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/categories/${id}`);
  }

  /**
   * Update category (Admin only)
   */
  updateCategory(id: number, name: string): Observable<{ message: string; category: Category }> {
    return this.http.put<{ message: string; category: Category }>(`${this.apiUrl}/categories/${id}`, { name });
  }

  // ==================== Items ====================

  /**
   * Get all items
   */
  getItems(): Observable<{ items: Item[] }> {
    return this.http.get<{ items: Item[] }>(`${this.apiUrl}/items`);
  }

  /**
   * Get items by category ID
   */
  getItemsByCategory(categoryId: number): Observable<{ items: Item[] }> {
    return this.http.get<{ items: Item[] }>(`${this.apiUrl}/items/category/${categoryId}`);
  }

  /**
   * Create item (Staff and Admin only)
   */
  createItem(name: string, categoryId: number): Observable<{ message: string; item: Item }> {
    return this.http.post<{ message: string; item: Item }>(`${this.apiUrl}/items`, { 
      name, 
      category_id: categoryId 
    });
  }

/**
   * Delete item (Staff and Admin only)
   */
  deleteItem(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/items/${id}`);
  }

  /**
   * Update item (Staff and Admin only)
   */
  updateItem(id: number, name: string, categoryId: number): Observable<{ message: string; item: Item }> {
    return this.http.put<{ message: string; item: Item }>(`${this.apiUrl}/items/${id}`, { 
      name, 
      category_id: categoryId 
    });
  }

  // ==================== Enrollments ====================

  /**
   * Enroll in an item (User only)
   */
  enroll(itemId: number): Observable<{ message: string; enrollment: Enrollment }> {
    return this.http.post<{ message: string; enrollment: Enrollment }>(`${this.apiUrl}/enrollments`, { item_id: itemId });
  }

  /**
   * Get my enrollments (User only)
   */
  getMyEnrollments(): Observable<{ enrollments: Enrollment[] }> {
    return this.http.get<{ enrollments: Enrollment[] }>(`${this.apiUrl}/enrollments/my`);
  }

  /**
   * Unenroll from an item (User only)
   */
  unenroll(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/enrollments/${id}`);
  }
}
