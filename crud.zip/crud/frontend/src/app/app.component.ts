import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="min-h-screen bg-gray-100">
      <!-- Navigation Bar -->
      <nav class="bg-blue-600 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
          <div class="flex justify-between items-center h-16">
            <!-- Logo -->
            <div class="flex-shrink-0">
              <a routerLink="/dashboard" class="text-xl font-bold">RBAC App</a>
            </div>
            
            <!-- Navigation Links -->
            <div class="flex items-center space-x-4">
              @if (authService.isLoggedIn()) {
                <span class="text-sm bg-blue-700 px-3 py-1 rounded">
                  {{ authService.getUserRole() | titlecase }}
                </span>
                <a routerLink="/dashboard" 
                   routerLinkActive="bg-blue-700" 
                   class="px-3 py-2 rounded hover:bg-blue-700 transition">
                  Dashboard
                </a>
                <button (click)="logout()" 
                        class="px-3 py-2 rounded hover:bg-blue-700 transition">
                  Logout
                </button>
              } @else {
                <a routerLink="/login" 
                   routerLinkActive="bg-blue-700" 
                   class="px-3 py-2 rounded hover:bg-blue-700 transition">
                  Login
                </a>
                <a routerLink="/signup" 
                   routerLinkActive="bg-blue-700" 
                   class="px-3 py-2 rounded hover:bg-blue-700 transition">
                  Signup
                </a>
              }
            </div>
          </div>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="max-w-7xl mx-auto px-4 py-8">
        <router-outlet></router-outlet>
      </main>
    </div>
  `
})
export class AppComponent {
  constructor(public authService: AuthService) {}

  logout(): void {
    this.authService.logout();
  }
}
