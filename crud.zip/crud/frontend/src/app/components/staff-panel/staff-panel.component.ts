import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, Category, Item } from '../../services/api.service';

@Component({
  selector: 'app-staff-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './staff-panel.component.html',
  styleUrls: ['./staff-panel.component.css']
})
export class StaffPanelComponent implements OnInit {
  // Form fields
  newItemName = '';
  selectedCategoryId: number | null = null;
  message = '';
  error = false;
  
  // Item edit state
  editingItemId: number | null = null;
  editingItemName = '';
  editingItemCategoryId: number | null = null;
  
  // Data
  categories: Category[] = [];
  items: Item[] = [];
  loading = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadCategories();
    this.loadItems();
  }

  loadCategories(): void {
    this.apiService.getCategories().subscribe({
      next: (response) => {
        this.categories = response.categories;
      },
      error: (err) => {
        console.error('Error loading categories:', err);
      }
    });
  }

  loadItems(): void {
    this.apiService.getItems().subscribe({
      next: (response) => {
        this.items = response.items;
      },
      error: (err) => {
        console.error('Error loading items:', err);
      }
    });
  }

  createItem(): void {
    if (!this.newItemName || !this.selectedCategoryId) {
      this.message = 'Please fill in all fields';
      this.error = true;
      return;
    }

    this.loading = true;
    this.message = '';
    this.error = false;

    this.apiService.createItem(this.newItemName, this.selectedCategoryId).subscribe({
      next: (response) => {
        this.loading = false;
        this.message = 'Item created successfully!';
        this.newItemName = '';
        this.selectedCategoryId = null;
        this.loadItems();
      },
      error: (err) => {
        this.loading = false;
        this.error = true;
        this.message = err.error?.message || 'Error creating item';
      }
    });
  }

deleteItem(id: number): void {
    if (!confirm('Are you sure you want to delete this item?')) {
      return;
    }

    this.loading = true;
    this.message = '';
    this.error = false;

    this.apiService.deleteItem(id).subscribe({
      next: (response) => {
        this.loading = false;
        this.message = response.message;
        this.loadItems();
      },
      error: (err) => {
        this.loading = false;
        this.error = true;
        this.message = err.error?.message || 'Error deleting item';
      }
    });
  }

  editItem(item: Item): void {
    this.editingItemId = item.id;
    this.editingItemName = item.name;
    this.editingItemCategoryId = item.category_id;
    this.message = '';
    this.error = false;
  }

  saveItem(id: number): void {
    if (!this.editingItemName.trim() || !this.editingItemCategoryId) {
      this.error = true;
      this.message = 'Item name and category are required';
      return;
    }

    this.loading = true;
    this.message = '';
    this.error = false;

    this.apiService.updateItem(id, this.editingItemName, this.editingItemCategoryId).subscribe({
      next: (response) => {
        this.loading = false;
        this.message = response.message;
        this.editingItemId = null;
        this.editingItemName = '';
        this.editingItemCategoryId = null;
        this.loadItems();
      },
      error: (err) => {
        this.loading = false;
        this.error = true;
        this.message = err.error?.message || 'Error updating item';
      }
    });
  }

  cancelEditItem(): void {
    this.editingItemId = null;
    this.editingItemName = '';
    this.editingItemCategoryId = null;
    this.message = '';
    this.error = false;
  }
}
