import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, Category, Item, Enrollment } from '../../services/api.service';

@Component({
  selector: 'app-user-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-panel.component.html',
  styleUrls: ['./user-panel.component.css']
})
export class UserPanelComponent implements OnInit {
  // Data
  categories: Category[] = [];
  items: Item[] = [];
  enrollments: Enrollment[] = [];
  selectedCategory: Category | null = null;
  enrolledItemIds: number[] = [];
  
  // State
  message = '';
  error = false;
  loading = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadCategories();
    this.loadEnrollments();
  }

  loadCategories(): void {
    this.apiService.getCategories().subscribe({
      next: (response) => {
        this.categories = response.categories;
      },
      error: (err) => {
        console.error('Error loading categories:', err);
      }
    });
  }

  loadItems(): void {
    if (!this.selectedCategory) {
      this.items = [];
      return;
    }

    this.apiService.getItemsByCategory(this.selectedCategory.id).subscribe({
      next: (response) => {
        this.items = response.items;
      },
      error: (err) => {
        console.error('Error loading items:', err);
      }
    });
  }

  loadEnrollments(): void {
    this.apiService.getMyEnrollments().subscribe({
      next: (response) => {
        this.enrollments = response.enrollments;
        // Store enrolled item IDs for quick lookup
        this.enrolledItemIds = response.enrollments.map(e => e.item_id);
      },
      error: (err) => {
        console.error('Error loading enrollments:', err);
      }
    });
  }

  selectCategory(category: Category): void {
    this.selectedCategory = category;
    this.loadItems();
  }

  isEnrolled(itemId: number): boolean {
    return this.enrolledItemIds.includes(itemId);
  }

  enroll(itemId: number): void {
    this.loading = true;
    this.message = '';
    this.error = false;

    this.apiService.enroll(itemId).subscribe({
      next: (response) => {
        this.loading = false;
        this.message = 'Enrolled successfully!';
        this.loadEnrollments();
        // Refresh items to update status
        this.loadItems();
      },
      error: (err) => {
        this.loading = false;
        this.error = true;
        this.message = err.error?.message || 'Error enrolling';
      }
    });
  }

  unenroll(enrollmentId: number): void {
    if (!confirm('Are you sure you want to unenroll?')) {
      return;
    }

    this.loading = true;
    this.message = '';
    this.error = false;

    this.apiService.unenroll(enrollmentId).subscribe({
      next: (response) => {
        this.loading = false;
        this.message = 'Unenrolled successfully!';
        this.loadEnrollments();
        // Refresh items to update status
        if (this.selectedCategory) {
          this.loadItems();
        }
      },
      error: (err) => {
        this.loading = false;
        this.error = true;
        this.message = err.error?.message || 'Error unenrolling';
      }
    });
  }
}
