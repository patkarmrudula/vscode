import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, Category } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})
export class AdminPanelComponent implements OnInit {
  // Category form
  newCategoryName = '';
  categoryMessage = '';
  categoryError = false;
  
  // Category edit state
  editingCategoryId: number | null = null;
  editingCategoryName = '';
  
  // Staff form
  newStaffName = '';
  newStaffEmail = '';
  newStaffPassword = '';
  staffMessage = '';
  staffError = false;
  
  // Data
  categories: Category[] = [];
  loading = false;

  constructor(
    private apiService: ApiService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories(): void {
    this.apiService.getCategories().subscribe({
      next: (response) => {
        this.categories = response.categories;
      },
      error: (err) => {
        console.error('Error loading categories:', err);
      }
    });
  }

  createCategory(): void {
    this.loading = true;
    this.categoryMessage = '';
    this.categoryError = false;

    this.apiService.createCategory(this.newCategoryName).subscribe({
      next: (response) => {
        this.loading = false;
        this.categoryMessage = response.message;
        this.newCategoryName = '';
        this.loadCategories();
      },
      error: (err) => {
        this.loading = false;
        this.categoryError = true;
        this.categoryMessage = err.error?.message || 'Error creating category';
      }
    });
  }

deleteCategory(id: number): void {
    if (!confirm('Are you sure you want to delete this category?')) {
      return;
    }

    this.loading = true;
    this.categoryMessage = '';
    this.categoryError = false;

    this.apiService.deleteCategory(id).subscribe({
      next: (response) => {
        this.loading = false;
        this.categoryMessage = response.message;
        this.loadCategories();
      },
      error: (err) => {
        this.loading = false;
        this.categoryError = true;
        this.categoryMessage = err.error?.message || 'Error deleting category';
      }
    });
  }

  editCategory(category: Category): void {
    this.editingCategoryId = category.id;
    this.editingCategoryName = category.name;
    this.categoryMessage = '';
    this.categoryError = false;
  }

  saveCategory(id: number): void {
    if (!this.editingCategoryName.trim()) {
      this.categoryError = true;
      this.categoryMessage = 'Category name is required';
      return;
    }

    this.loading = true;
    this.categoryMessage = '';
    this.categoryError = false;

    this.apiService.updateCategory(id, this.editingCategoryName).subscribe({
      next: (response) => {
        this.loading = false;
        this.categoryMessage = response.message;
        this.editingCategoryId = null;
        this.editingCategoryName = '';
        this.loadCategories();
      },
      error: (err) => {
        this.loading = false;
        this.categoryError = true;
        this.categoryMessage = err.error?.message || 'Error updating category';
      }
    });
  }

  cancelEditCategory(): void {
    this.editingCategoryId = null;
    this.editingCategoryName = '';
    this.categoryMessage = '';
    this.categoryError = false;
  }

  createStaff(): void {
    this.loading = true;
    this.staffMessage = '';
    this.staffError = false;

    this.authService.createStaff(this.newStaffName, this.newStaffEmail, this.newStaffPassword).subscribe({
next: (response) => {
        this.loading = false;
        this.staffMessage = 'Staff user created successfully!';
        this.newStaffName = '';
        this.newStaffEmail = '';
        this.newStaffPassword = '';
      },
      error: (err) => {
        this.loading = false;
        this.staffError = true;
        this.staffMessage = err.error?.message || 'Error creating staff user';
      }
    });
  }
}
