import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is logged in
  if (authService.isLoggedIn()) {
    return true;
  }

  // Redirect to login page
  router.navigate(['/login']);
  return false;
};

export const adminGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is logged in and is admin
  if (authService.isLoggedIn() && authService.isAdmin()) {
    return true;
  }

  // Redirect to dashboard
  router.navigate(['/dashboard']);
  return false;
};

export const staffGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is logged in and is staff or admin
  if (authService.isLoggedIn() && (authService.isStaff() || authService.isAdmin())) {
    return true;
  }

  // Redirect to dashboard
  router.navigate(['/dashboard']);
  return false;
};

export const userGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is logged in and is regular user
  if (authService.isLoggedIn() && authService.isUser()) {
    return true;
  }

  // Redirect to dashboard
  router.navigate(['/dashboard']);
  return false;
};

export const guestGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is NOT logged in
  if (!authService.isLoggedIn()) {
    return true;
  }

  // Redirect to dashboard
  router.navigate(['/dashboard']);
  return false;
};
