import { Routes } from '@angular/router';
import { authGuard, adminGuard, staffGuard, guestGuard } from './guards/auth.guard';

// Import components
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AdminPanelComponent } from './components/admin-panel/admin-panel.component';
import { StaffPanelComponent } from './components/staff-panel/staff-panel.component';
import { UserPanelComponent } from './components/user-panel/user-panel.component';

export const routes: Routes = [
  // Default route - redirect to login
  { 
    path: '', 
    redirectTo: 'login', 
    pathMatch: 'full' 
  },
  // Login route (guest only)
  { 
    path: 'login', 
    component: LoginComponent,
    canActivate: [guestGuard]
  },
  // Signup route (guest only)
  { 
    path: 'signup', 
    component: SignupComponent,
    canActivate: [guestGuard]
  },
  // Dashboard route (all authenticated users)
  { 
    path: 'dashboard', 
    component: DashboardComponent,
    canActivate: [authGuard]
  },
  // Admin panel route (admin only)
  { 
    path: 'admin-panel', 
    component: AdminPanelComponent,
    canActivate: [authGuard, adminGuard]
  },
  // Staff panel route (staff and admin)
  { 
    path: 'staff-panel', 
    component: StaffPanelComponent,
    canActivate: [authGuard, staffGuard]
  },
  // User panel route (regular users)
  { 
    path: 'user-panel', 
    component: UserPanelComponent,
    canActivate: [authGuard]
  },
  // Wildcard route - redirect to login
  { 
    path: '**', 
    redirectTo: 'login' 
  }
];
