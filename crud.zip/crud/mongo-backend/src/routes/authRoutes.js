/**
 * Auth Routes
 * Handles all authentication related routes
 */

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyJWT, adminOnly } = require('../middleware/authMiddleware');

// Public routes (no authentication required)

// POST /api/auth/signup - Register a new user
router.post('/signup', authController.signup);

// POST /api/auth/login - Login user
router.post('/login', authController.login);

// Protected routes (authentication required)

// GET /api/auth/me - Get current user profile
router.get('/me', verifyJWT, authController.getMe);

// POST /api/auth/create-staff - Create staff user (Admin only)
router.post('/create-staff', verifyJWT, adminOnly, authController.createStaff);

module.exports = router;

