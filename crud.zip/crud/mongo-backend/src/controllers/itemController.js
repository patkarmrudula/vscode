/**
 * Item Controller (MongoDB)
 */

const itemModel = require('../models/itemModel');
const categoryModel = require('../models/categoryModel');

/**
 * POST /items
 * Create a new item (Staff and Admin only)
 */
const createItem = async (req, res) => {
  try {
    const { name, category_id } = req.body;

    if (!name || !category_id) {
      return res.status(400).json({ message: 'Item name and category_id are required' });
    }

    const category = await categoryModel.getCategoryById(category_id);
    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    const item = await itemModel.createItem({ name, category_id });

    res.status(201).json({
      message: 'Item created successfully',
      item: {
        ...item,
        category_name: category.name,
      },
    });
  } catch (error) {
    console.error('Create item error:', error);
    res.status(500).json({ message: 'Error creating item' });
  }
};

/**
 * GET /items
 * Get all items (All authenticated users)
 */
const getItems = async (req, res) => {
  try {
    const items = await itemModel.getAllItems();

    res.json({
      items,
    });
  } catch (error) {
    console.error('Get items error:', error);
    res.status(500).json({ message: 'Error getting items' });
  }
};

/**
 * GET /items/:category_id
 * Get items by category ID (All authenticated users)
 */
const getItemsByCategoryId = async (req, res) => {
  try {
    const { category_id } = req.params;
    const items = await itemModel.getItemsByCategoryId(category_id);

    res.json({
      items,
    });
  } catch (error) {
    console.error('Get items error:', error);
    res.status(500).json({ message: 'Error getting items' });
  }
};

/**
 * GET /items/item/:id
 * Get item by ID
 */
const getItemById = async (req, res) => {
  try {
    const { id } = req.params;
    const item = await itemModel.getItemById(id);

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    res.json({ item });
  } catch (error) {
    console.error('Get item error:', error);
    res.status(500).json({ message: 'Error getting item' });
  }
};

/**
 * PUT /items/:id
 * Update item (Staff and Admin only)
 */
const updateItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category_id } = req.body;

    if (!name || !category_id) {
      return res.status(400).json({ message: 'Item name and category_id are required' });
    }

    const existingItem = await itemModel.getItemById(id);
    if (!existingItem) {
      return res.status(404).json({ message: 'Item not found' });
    }

    const category = await categoryModel.getCategoryById(category_id);
    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    const item = await itemModel.updateItem(id, { name, category_id });

    res.json({
      message: 'Item updated successfully',
      item: {
        ...item,
        category_name: category.name,
      },
    });
  } catch (error) {
    console.error('Update item error:', error);
    res.status(500).json({ message: 'Error updating item' });
  }
};

/**
 * DELETE /items/:id
 * Delete item (Staff and Admin only)
 */
const deleteItem = async (req, res) => {
  try {
    const { id } = req.params;

    const existingItem = await itemModel.getItemById(id);
    if (!existingItem) {
      return res.status(404).json({ message: 'Item not found' });
    }

    const item = await itemModel.deleteItem(id);

    res.json({
      message: 'Item deleted successfully',
      item,
    });
  } catch (error) {
    console.error('Delete item error:', error);
    res.status(500).json({ message: 'Error deleting item' });
  }
};

module.exports = {
  createItem,
  getItems,
  getItemsByCategoryId,
  getItemById,
  updateItem,
  deleteItem,
};

