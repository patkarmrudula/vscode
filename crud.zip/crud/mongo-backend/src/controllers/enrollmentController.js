/**
 * Enrollment Controller (MongoDB)
 */

const enrollmentModel = require('../models/enrollmentModel');
const itemModel = require('../models/itemModel');

/**
 * POST /enroll
 * Enroll user in an item (User only)
 */
const createEnrollment = async (req, res) => {
  try {
    const { item_id } = req.body;
    const user_id = req.user.id;

    if (!item_id) {
      return res.status(400).json({ message: 'Item ID is required' });
    }

    const item = await itemModel.getItemById(item_id);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    const existingEnrollment = await enrollmentModel.checkEnrollment(user_id, item_id);
    if (existingEnrollment) {
      return res.status(400).json({ message: 'Already enrolled in this item' });
    }

    const enrollment = await enrollmentModel.createEnrollment({ userId: user_id, itemId: item_id });

    res.status(201).json({
      message: 'Enrolled successfully',
      enrollment: {
        id: enrollment._id,
        user_id: enrollment.userId._id,
        item_id: enrollment.itemId._id,
        created_at: enrollment.createdAt,
        item_name: item.name,
        category_name: item.category_name,
      },
    });
  } catch (error) {
    console.error('Create enrollment error:', error);
    res.status(500).json({ message: 'Error creating enrollment' });
  }
};

/**
 * GET /my-enrollments
 * Get all enrollments for current user (User only)
 */
const getMyEnrollments = async (req, res) => {
  try {
    const user_id = req.user.id;
    const enrollments = await enrollmentModel.getEnrollmentsByUserId(user_id);

    res.json({
      enrollments,
    });
  } catch (error) {
    console.error('Get enrollments error:', error);
    res.status(500).json({ message: 'Error getting enrollments' });
  }
};

/**
 * DELETE /enroll/:id
 * Unenroll from an item (User only)
 */
const deleteEnrollment = async (req, res) => {
  try {
    const { id } = req.params;
    const user_id = req.user.id;

    const enrollment = await enrollmentModel.getEnrollmentById(id);
    
    if (!enrollment) {
      return res.status(404).json({ message: 'Enrollment not found' });
    }

    if (enrollment.user_id.toString() !== user_id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }

    await enrollmentModel.deleteEnrollment(id);

    res.json({
      message: 'Unenrolled successfully',
    });
  } catch (error) {
    console.error('Delete enrollment error:', error);
    res.status(500).json({ message: 'Error deleting enrollment' });
  }
};

/**
 * GET /enrollments
 * Get all enrollments (Admin only)
 */
const getAllEnrollments = async (req, res) => {
  try {
    const enrollments = await enrollmentModel.getAllEnrollments();

    res.json({
      enrollments,
    });
  } catch (error) {
    console.error('Get all enrollments error:', error);
    res.status(500).json({ message: 'Error getting enrollments' });
  }
};

module.exports = {
  createEnrollment,
  getMyEnrollments,
  deleteEnrollment,
  getAllEnrollments,
};

