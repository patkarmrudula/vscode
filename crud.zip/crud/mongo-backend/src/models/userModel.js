const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { 
    type: String, 
    enum: ['admin', 'staff', 'user'], 
    default: 'user' 
  }
}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

const User = mongoose.model('User', userSchema);

module.exports = {
  createUser: async (userData) => {
    const user = new User(userData);
    await user.save();
    return user.toObject(); // exclude password
  },
  findUserByEmail: async (email) => User.findOne({ email }).lean(),
  findUserById: async (id) => User.findById(id).select('-password').lean(),
  getAllUsers: async () => User.find().select('-password').sort({ createdAt: -1 }).lean(),
  updateUserRole: async (id, role) => User.findByIdAndUpdate(id, { role }, { new: true }).select('-password').lean(),
  validatePassword: async (email, password) => {
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password))) return null;
    return user.toObject({ versionKey: false, transform: (doc, ret) => { delete ret.password; return ret; } });
  }
};
