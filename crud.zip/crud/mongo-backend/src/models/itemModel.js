const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  categoryId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Category', 
    required: true 
  }
}, { timestamps: true });

const Item = mongoose.model('Item', itemSchema);

module.exports = {
  createItem: async (itemData) => {
    const item = new Item(itemData);
    await item.save();
    return (await item.populate('categoryId', 'name')).toObject();
  },
  getAllItems: async () => {
    const items = await Item.find().populate('categoryId', 'name').sort({ createdAt: -1 }).lean();
    return items.map(item => ({
      ...item,
      category_name: item.categoryId?.name || null
    }));
  },
  getItemsByCategoryId: async (categoryId) => {
    const items = await Item.find({ categoryId }).populate('categoryId', 'name').sort({ createdAt: -1 }).lean();
    return items.map(item => ({
      ...item,
      category_name: item.categoryId?.name || null
    }));
  },
  getItemById: async (id) => {
    const item = await Item.findById(id).populate('categoryId', 'name').lean();
    return item ? { ...item, category_name: item.categoryId?.name || null } : null;
  },
  updateItem: async (id, itemData) => {
    const item = await Item.findByIdAndUpdate(id, itemData, { new: true }).populate('categoryId', 'name').lean();
    return item ? { ...item, category_name: item.categoryId?.name || null } : null;
  },
  deleteItem: async (id) => Item.findByIdAndDelete(id).lean()
};
