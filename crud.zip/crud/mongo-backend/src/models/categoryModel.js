const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
  name: { type: String, required: true }
}, { timestamps: true });

const Category = mongoose.model('Category', categorySchema);

module.exports = {
  createCategory: async (categoryData) => {
    const category = new Category(categoryData);
    await category.save();
    return category.toObject();
  },
  getAllCategories: async () => Category.find().sort({ createdAt: -1 }).lean(),
  getCategoryById: async (id) => Category.findById(id).lean(),
  updateCategory: async (id, categoryData) => Category.findByIdAndUpdate(id, categoryData, { new: true }).lean(),
  deleteCategory: async (id) => Category.findByIdAndDelete(id).lean()
};
