const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  itemId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Item', 
    required: true 
  }
}, { timestamps: true });

const Enrollment = mongoose.model('Enrollment', enrollmentSchema);

module.exports = {
  createEnrollment: async (enrollmentData) => {
    const enrollment = new Enrollment(enrollmentData);
    await enrollment.save();
    return (await enrollment.populate([{ path: 'userId', select: 'name email' }, { path: 'itemId', populate: { path: 'categoryId', select: 'name' } }])).toObject();
  },
  getEnrollmentsByUserId: async (userId) => {
    const enrollments = await Enrollment.find({ userId }).populate([
      { path: 'itemId', select: 'name categoryId' },
      { path: 'itemId.categoryId', select: 'name' }
    ]).sort({ createdAt: -1 }).lean();
    return enrollments.map(enr => ({
      id: enr._id,
      user_id: enr.userId._id,
      item_id: enr.itemId._id,
      created_at: enr.createdAt,
      item_name: enr.itemId.name,
      category_id: enr.itemId.categoryId._id,
      category_name: enr.itemId.categoryId?.name || null
    }));
  },
  getEnrollmentById: async (id) => {
    const enrollment = await Enrollment.findById(id).populate('itemId', 'name').lean();
    return enrollment ? {
      id: enrollment._id,
      user_id: enrollment.userId,
      item_id: enrollment.itemId._id,
      created_at: enrollment.createdAt,
      item_name: enrollment.itemId.name
    } : null;
  },
  checkEnrollment: async (userId, itemId) => Enrollment.findOne({ userId, itemId }).lean(),
  deleteEnrollment: async (id) => {
    const enr = await Enrollment.findByIdAndDelete(id).lean();
    return enr ? { id: enr._id, user_id: enr.userId, item_id: enr.itemId, created_at: enr.createdAt } : null;
  },
  getAllEnrollments: async () => {
    const enrollments = await Enrollment.find().populate([
      { path: 'userId', select: 'name email' },
      { path: 'itemId', select: 'name categoryId' },
      { path: 'itemId.categoryId', select: 'name' }
    ]).sort({ createdAt: -1 }).lean();
    return enrollments.map(enr => ({
      id: enr._id,
      user_id: enr.userId._id,
      item_id: enr.itemId._id,
      created_at: enr.createdAt,
      user_name: enr.userId.name,
      user_email: enr.userId.email,
      item_name: enr.itemId.name,
      category_name: enr.itemId.categoryId?.name || null
    }));
  }
};
