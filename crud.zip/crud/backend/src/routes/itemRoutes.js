/**
 * Item Routes
 * Handles all item related routes
 */

const express = require('express');
const router = express.Router();
const itemController = require('../controllers/itemController');
const { verifyJWT, staffOrAdmin } = require('../middleware/authMiddleware');

// All item routes require authentication

// GET /api/items - Get all items
router.get('/', verifyJWT, itemController.getItems);

// GET /api/items/category/:category_id - Get items by category ID
router.get('/category/:category_id', verifyJWT, itemController.getItemsByCategoryId);

// GET /api/items/item/:id - Get item by ID
router.get('/item/:id', verifyJWT, itemController.getItemById);

// POST /api/items - Create item (Staff and Admin only)
router.post('/', verifyJWT, staffOrAdmin, itemController.createItem);

// PUT /api/items/:id - Update item (Staff and Admin only)
router.put('/:id', verifyJWT, staffOrAdmin, itemController.updateItem);

// DELETE /api/items/:id - Delete item (Staff and Admin only)
router.delete('/:id', verifyJWT, staffOrAdmin, itemController.deleteItem);

module.exports = router;
