/**
 * Enrollment Routes
 * Handles all enrollment related routes
 */

const express = require('express');
const router = express.Router();
const enrollmentController = require('../controllers/enrollmentController');
const { verifyJWT, adminOnly } = require('../middleware/authMiddleware');

// All enrollment routes require authentication

// GET /api/enrollments - Get all enrollments (Admin only)
router.get('/', verifyJWT, adminOnly, enrollmentController.getAllEnrollments);

// GET /api/enrollments/my - Get current user's enrollments (User only)
router.get('/my', verifyJWT, enrollmentController.getMyEnrollments);

// POST /api/enrollments - Create enrollment (User only)
router.post('/', verifyJWT, enrollmentController.createEnrollment);

// DELETE /api/enrollments/:id - Delete enrollment (User only)
router.delete('/:id', verifyJWT, enrollmentController.deleteEnrollment);

module.exports = router;
