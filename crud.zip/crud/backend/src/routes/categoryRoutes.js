/**
 * Category Routes
 * Handles all category related routes
 */

const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');
const { verifyJWT, adminOnly } = require('../middleware/authMiddleware');

// All category routes require authentication

// GET /api/categories - Get all categories
router.get('/', verifyJWT, categoryController.getCategories);

// GET /api/categories/:id - Get category by ID
router.get('/:id', verifyJWT, categoryController.getCategoryById);

// POST /api/categories - Create category (Admin only)
router.post('/', verifyJWT, adminOnly, categoryController.createCategory);

// PUT /api/categories/:id - Update category (Admin only)
router.put('/:id', verifyJWT, adminOnly, categoryController.updateCategory);

// DELETE /api/categories/:id - Delete category (Admin only)
router.delete('/:id', verifyJWT, adminOnly, categoryController.deleteCategory);

module.exports = router;
