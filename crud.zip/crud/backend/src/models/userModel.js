/**
 * User Model
 * Handles all database operations for users
 */

const db = require('../config/db');

/**
 * Create a new user
 * @param {Object} user - User object with name, email, password, role
 * @returns {Promise} Created user (without password)
 */
const createUser = async (user) => {
  const { name, email, password, role = 'user' } = user;
  
  const query = `
    INSERT INTO users (name, email, password, role)
    VALUES ($1, $2, $3, $4)
    RETURNING id, name, email, role, created_at
  `;
  
  const result = await db.query(query, [name, email, password, role]);
  return result.rows[0];
};

/**
 * Find user by email
 * @param {string} email - User email
 * @returns {Promise} User object (with password)
 */
const findUserByEmail = async (email) => {
  const query = 'SELECT * FROM users WHERE email = $1';
  const result = await db.query(query, [email]);
  return result.rows[0];
};

/**
 * Find user by ID
 * @param {number} id - User ID
 * @returns {Promise} User object (without password)
 */
const findUserById = async (id) => {
  const query = 'SELECT id, name, email, role, created_at FROM users WHERE id = $1';
  const result = await db.query(query, [id]);
  return result.rows[0];
};

/**
 * Get all users (Admin only)
 * @returns {Promise} Array of users
 */
const getAllUsers = async () => {
  const query = 'SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC';
  const result = await db.query(query);
  return result.rows;
};

/**
 * Update user role (Admin only)
 * @param {number} id - User ID
 * @param {string} role - New role
 * @returns {Promise} Updated user
 */
const updateUserRole = async (id, role) => {
  const query = `
    UPDATE users 
    SET role = $1 
    WHERE id = $2 
    RETURNING id, name, email, role, created_at
  `;
  const result = await db.query(query, [role, id]);
  return result.rows[0];
};

/**
 * Validate user password
 * @param {string} email - User email
 * @param {string} password - Plain text password
 * @returns {Promise} User object if valid, null if invalid
 */
const validatePassword = async (email, password) => {
  const user = await findUserByEmail(email);
  
  if (!user) {
    return null;
  }
  
  // Compare plain text passwords
  if (password !== user.password) {
    return null;
  }
  
  // Return user without password
  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

module.exports = {
  createUser,
  findUserByEmail,
  findUserById,
  getAllUsers,
  updateUserRole,
  validatePassword,
};
