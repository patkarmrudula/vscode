/**
 * Item Model
 * Handles all database operations for items
 */

const db = require('../config/db');

/**
 * Create a new item
 * @param {Object} item - Item object with name, category_id
 * @returns {Promise} Created item
 */
const createItem = async (item) => {
  const { name, category_id } = item;
  
  const query = `
    INSERT INTO items (name, category_id)
    VALUES ($1, $2)
    RETURNING id, name, category_id, created_at
  `;
  
  const result = await db.query(query, [name, category_id]);
  return result.rows[0];
};

/**
 * Get all items
 * @returns {Promise} Array of items
 */
const getAllItems = async () => {
  const query = `
    SELECT i.id, i.name, i.category_id, c.name as category_name, i.created_at 
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    ORDER BY i.created_at DESC
  `;
  const result = await db.query(query);
  return result.rows;
};

/**
 * Get items by category ID
 * @param {number} category_id - Category ID
 * @returns {Promise} Array of items
 */
const getItemsByCategoryId = async (category_id) => {
  const query = `
    SELECT i.id, i.name, i.category_id, c.name as category_name, i.created_at 
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    WHERE i.category_id = $1
    ORDER BY i.created_at DESC
  `;
  const result = await db.query(query, [category_id]);
  return result.rows;
};

/**
 * Get item by ID
 * @param {number} id - Item ID
 * @returns {Promise} Item object
 */
const getItemById = async (id) => {
  const query = `
    SELECT i.id, i.name, i.category_id, c.name as category_name, i.created_at 
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    WHERE i.id = $1
  `;
  const result = await db.query(query, [id]);
  return result.rows[0];
};

/**
 * Update item
 * @param {number} id - Item ID
 * @param {Object} item - Item object with name, category_id
 * @returns {Promise} Updated item
 */
const updateItem = async (id, item) => {
  const { name, category_id } = item;
  
  const query = `
    UPDATE items 
    SET name = $1, category_id = $2 
    WHERE id = $3 
    RETURNING id, name, category_id, created_at
  `;
  
  const result = await db.query(query, [name, category_id, id]);
  return result.rows[0];
};

/**
 * Delete item
 * @param {number} id - Item ID
 * @returns {Promise} Deleted item
 */
const deleteItem = async (id) => {
  const query = `
    DELETE FROM items 
    WHERE id = $1 
    RETURNING id, name, category_id, created_at
  `;
  
  const result = await db.query(query, [id]);
  return result.rows[0];
};

module.exports = {
  createItem,
  getAllItems,
  getItemsByCategoryId,
  getItemById,
  updateItem,
  deleteItem,
};
