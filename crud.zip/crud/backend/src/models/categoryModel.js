/**
 * Category Model
 * Handles all database operations for categories
 */

const db = require('../config/db');

/**
 * Create a new category
 * @param {Object} category - Category object with name
 * @returns {Promise} Created category
 */
const createCategory = async (category) => {
  const { name } = category;
  
  const query = `
    INSERT INTO categories (name)
    VALUES ($1)
    RETURNING id, name, created_at
  `;
  
  const result = await db.query(query, [name]);
  return result.rows[0];
};

/**
 * Get all categories
 * @returns {Promise} Array of categories
 */
const getAllCategories = async () => {
  const query = 'SELECT id, name, created_at FROM categories ORDER BY created_at DESC';
  const result = await db.query(query);
  return result.rows;
};

/**
 * Get category by ID
 * @param {number} id - Category ID
 * @returns {Promise} Category object
 */
const getCategoryById = async (id) => {
  const query = 'SELECT id, name, created_at FROM categories WHERE id = $1';
  const result = await db.query(query, [id]);
  return result.rows[0];
};

/**
 * Update category
 * @param {number} id - Category ID
 * @param {Object} category - Category object with name
 * @returns {Promise} Updated category
 */
const updateCategory = async (id, category) => {
  const { name } = category;
  
  const query = `
    UPDATE categories 
    SET name = $1 
    WHERE id = $2 
    RETURNING id, name, created_at
  `;
  
  const result = await db.query(query, [name, id]);
  return result.rows[0];
};

/**
 * Delete category
 * @param {number} id - Category ID
 * @returns {Promise} Deleted category
 */
const deleteCategory = async (id) => {
  const query = `
    DELETE FROM categories 
    WHERE id = $1 
    RETURNING id, name, created_at
  `;
  
  const result = await db.query(query, [id]);
  return result.rows[0];
};

module.exports = {
  createCategory,
  getAllCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
};
