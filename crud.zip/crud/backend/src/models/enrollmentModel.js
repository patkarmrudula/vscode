/**
 * Enrollment Model
 * Handles all database operations for enrollments
 */

const db = require('../config/db');

/**
 * Create a new enrollment
 * @param {Object} enrollment - Enrollment object with user_id, item_id
 * @returns {Promise} Created enrollment
 */
const createEnrollment = async (enrollment) => {
  const { user_id, item_id } = enrollment;
  
  const query = `
    INSERT INTO enrollments (user_id, item_id)
    VALUES ($1, $2)
    RETURNING id, user_id, item_id, created_at
  `;
  
  const result = await db.query(query, [user_id, item_id]);
  return result.rows[0];
};

/**
 * Get all enrollments for a user
 * @param {number} user_id - User ID
 * @returns {Promise} Array of enrollments with item details
 */
const getEnrollmentsByUserId = async (user_id) => {
  const query = `
    SELECT e.id, e.user_id, e.item_id, e.created_at,
           i.name as item_name, i.category_id,
           c.name as category_name
    FROM enrollments e
    LEFT JOIN items i ON e.item_id = i.id
    LEFT JOIN categories c ON i.category_id = c.id
    WHERE e.user_id = $1
    ORDER BY e.created_at DESC
  `;
  const result = await db.query(query, [user_id]);
  return result.rows;
};

/**
 * Get enrollment by ID
 * @param {number} id - Enrollment ID
 * @returns {Promise} Enrollment object
 */
const getEnrollmentById = async (id) => {
  const query = `
    SELECT e.id, e.user_id, e.item_id, e.created_at,
           i.name as item_name
    FROM enrollments e
    LEFT JOIN items i ON e.item_id = i.id
    WHERE e.id = $1
  `;
  const result = await db.query(query, [id]);
  return result.rows[0];
};

/**
 * Check if user is enrolled in an item
 * @param {number} user_id - User ID
 * @param {number} item_id - Item ID
 * @returns {Promise} Enrollment object if exists, null otherwise
 */
const checkEnrollment = async (user_id, item_id) => {
  const query = `
    SELECT * FROM enrollments 
    WHERE user_id = $1 AND item_id = $2
  `;
  const result = await db.query(query, [user_id, item_id]);
  return result.rows[0] || null;
};

/**
 * Delete enrollment
 * @param {number} id - Enrollment ID
 * @returns {Promise} Deleted enrollment
 */
const deleteEnrollment = async (id) => {
  const query = `
    DELETE FROM enrollments 
    WHERE id = $1 
    RETURNING id, user_id, item_id, created_at
  `;
  
  const result = await db.query(query, [id]);
  return result.rows[0];
};

/**
 * Get all enrollments (Admin only)
 * @returns {Promise} Array of enrollments
 */
const getAllEnrollments = async () => {
  const query = `
    SELECT e.id, e.user_id, e.item_id, e.created_at,
           u.name as user_name, u.email as user_email,
           i.name as item_name, c.name as category_name
    FROM enrollments e
    LEFT JOIN users u ON e.user_id = u.id
    LEFT JOIN items i ON e.item_id = i.id
    LEFT JOIN categories c ON i.category_id = c.id
    ORDER BY e.created_at DESC
  `;
  const result = await db.query(query);
  return result.rows;
};

module.exports = {
  createEnrollment,
  getEnrollmentsByUserId,
  getEnrollmentById,
  checkEnrollment,
  deleteEnrollment,
  getAllEnrollments,
};
