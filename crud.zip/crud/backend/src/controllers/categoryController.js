/**
 * Category Controller
 * Handles all category related operations
 */

const categoryModel = require('../models/categoryModel');

/**
 * POST /categories
 * Create a new category (Admin only)
 */
const createCategory = async (req, res) => {
  try {
    const { name } = req.body;

    // Validate required fields
    if (!name) {
      return res.status(400).json({ message: 'Category name is required' });
    }

    // Check if category already exists
    const categories = await categoryModel.getAllCategories();
    const existingCategory = categories.find(c => c.name.toLowerCase() === name.toLowerCase());
    
    if (existingCategory) {
      return res.status(400).json({ message: 'Category with this name already exists' });
    }

    // Create category
    const category = await categoryModel.createCategory({ name });

    res.status(201).json({
      message: 'Category created successfully',
      category,
    });
  } catch (error) {
    console.error('Create category error:', error);
    res.status(500).json({ message: 'Error creating category' });
  }
};

/**
 * GET /categories
 * Get all categories (All authenticated users)
 */
const getCategories = async (req, res) => {
  try {
    const categories = await categoryModel.getAllCategories();

    res.json({
      categories,
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ message: 'Error getting categories' });
  }
};

/**
 * GET /categories/:id
 * Get category by ID
 */
const getCategoryById = async (req, res) => {
  try {
    const { id } = req.params;
    const category = await categoryModel.getCategoryById(id);

    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    res.json({ category });
  } catch (error) {
    console.error('Get category error:', error);
    res.status(500).json({ message: 'Error getting category' });
  }
};

/**
 * PUT /categories/:id
 * Update category (Admin only)
 */
const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;

    // Validate required fields
    if (!name) {
      return res.status(400).json({ message: 'Category name is required' });
    }

    // Check if category exists
    const existingCategory = await categoryModel.getCategoryById(id);
    if (!existingCategory) {
      return res.status(404).json({ message: 'Category not found' });
    }

    // Update category
    const category = await categoryModel.updateCategory(id, { name });

    res.json({
      message: 'Category updated successfully',
      category,
    });
  } catch (error) {
    console.error('Update category error:', error);
    res.status(500).json({ message: 'Error updating category' });
  }
};

/**
 * DELETE /categories/:id
 * Delete category (Admin only)
 */
const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if category exists
    const existingCategory = await categoryModel.getCategoryById(id);
    if (!existingCategory) {
      return res.status(404).json({ message: 'Category not found' });
    }

    // Delete category
    const category = await categoryModel.deleteCategory(id);

    res.json({
      message: 'Category deleted successfully',
      category,
    });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ message: 'Error deleting category' });
  }
};

module.exports = {
  createCategory,
  getCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
};
