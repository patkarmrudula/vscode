const { Client } = require('pg');
const http = require('http');

async function testAPIs() {
    // 1. Check DB Data
    const client = new Client({
        user: '23510082',
        password: 'Mrudula@6',
        host: 'localhost',
        port: 5432,
        database: 'university',
    });

    console.log('--- Database Check ---');
    try {
        await client.connect();
        const res = await client.query('SELECT count(*) FROM student');
        console.log('Student count:', res.rows[0].count);

        const schemaRes = await client.query("SELECT column_name FROM information_schema.columns WHERE table_name = 'student'");
        console.log('Student columns:', schemaRes.rows.map(r => r.column_name).join(', '));
    } catch (err) {
        console.error('DB Error:', err.message);
    } finally {
        await client.end();
    }

    // 2. Check API (Login first to get token)
    console.log('\n--- API Check ---');
    const loginData = JSON.stringify({ username: 'admin', password: 'admin123' });

    const loginReq = http.request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/auth/login',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': loginData.length
        }
    }, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
            const token = JSON.parse(data).token;
            console.log('Got Token:', token ? 'Yes' : 'No');

            if (token) {
                // Check Schema API
                checkEndpoint(token, '/api/student/schema', 'Schema API');
                // Check Data API
                checkEndpoint(token, '/api/student', 'Data API');
            }
        });
    });

    loginReq.write(loginData);
    loginReq.end();
}

function checkEndpoint(token, path, name) {
    const req = http.request({
        hostname: 'localhost',
        port: 3000,
        path: path,
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    }, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
            console.log(`${name} Status:`, res.statusCode);
            console.log(`${name} Data Length:`, data.length);
            if (res.statusCode !== 200) console.log(`${name} Response:`, data);
        });
    });
    req.end();
}

testAPIs();
