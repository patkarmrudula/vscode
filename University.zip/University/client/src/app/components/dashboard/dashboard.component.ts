import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet],
  template: `
    <div class="flex h-screen bg-gray-100">
      <!-- Sidebar -->
      <div class="w-64 bg-white shadow-md">
        <div class="p-6">
          <h1 class="text-xl font-bold text-blue-600">Uni MIS</h1>
          <p class="text-sm text-gray-500">Welcome, {{ authService.currentUser()?.username }}</p>
          <p class="text-xs text-gray-400 capitalize">{{ authService.currentUser()?.role }}</p>
        </div>
        <nav class="mt-6">
          <ng-container *ngIf="authService.currentUser()?.role === 'Admin'">
            <a routerLink="/dashboard/students" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">Students</a>
            <a routerLink="/dashboard/courses" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">Courses</a>
            <a routerLink="/dashboard/instructors" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">Instructors</a>
            <a routerLink="/dashboard/departments" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">Departments</a>
            <a routerLink="/dashboard/reports/classroom" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">Classrooms</a>
          </ng-container>

          <ng-container *ngIf="authService.currentUser()?.role === 'Student'">
            <a routerLink="/dashboard/courses" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">My Courses</a>
            <a routerLink="/dashboard/departments" class="block px-6 py-2 hover:bg-gray-100 text-gray-700">Departments</a>
            <!-- Link to specific profile if linked_id exists, else list -->
            <a [routerLink]="AuthUser?.linked_id ? ['/dashboard/forms/student/edit', AuthUser.linked_id] : '/dashboard/students'" 
               class="block px-6 py-2 hover:bg-gray-100 text-gray-700">My Profile</a> 
          </ng-container>

          <div class="border-t mt-4 pt-4">
             <button (click)="authService.logout()" class="block w-full text-left px-6 py-2 text-red-600 hover:bg-red-50">Logout</button>
          </div>
        </nav>
      </div>

      <!-- Main Content -->
      <div class="flex-1 overflow-y-auto p-8">
        <router-outlet></router-outlet>
      </div>
    </div>
  `
})
export class DashboardComponent {
  authService = inject(AuthService);

  get AuthUser(): any {
    return this.authService.currentUser();
  }
}
