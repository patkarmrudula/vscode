import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [CommonModule, FormsModule],
    template: `
    <div class="flex items-center justify-center min-h-screen bg-gray-100">
      <div class="px-8 py-6 mt-4 text-left bg-white shadow-lg rounded-xl">
        <h3 class="text-2xl font-bold text-center">Login to University MIS</h3>
        <form (ngSubmit)="onSubmit()">
          <div class="mt-4">
            <div>
              <label class="block" for="username">Username</label>
              <input type="text" placeholder="Username" id="username" [(ngModel)]="username" name="username"
                class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
            </div>
            <div class="mt-4">
              <label class="block" for="password">Password</label>
              <input type="password" placeholder="Password" id="password" [(ngModel)]="password" name="password"
                class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
            </div>
            <div class="flex items-baseline justify-between">
              <button class="px-6 py-2 mt-4 text-white bg-blue-600 rounded-lg hover:bg-blue-900">Login</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  `,
    styles: []
})
export class LoginComponent {
    username = '';
    password = '';
    authService = inject(AuthService);

    onSubmit() {
        this.authService.login({ username: this.username, password: this.password }).subscribe({
            next: () => console.log('Login successful'),
            error: (err) => alert('Login failed: ' + err.error.message)
        });
    }
}
