import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { ENTITY_METADATA } from '../../config/entity-metadata';

@Component({
  selector: 'app-generic-report',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="bg-white p-6 rounded-lg shadow-md">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">{{ conf?.label || tableName | titlecase }} Report</h2>
          <p class="text-gray-500">{{ data.length }} records found</p>
        </div>
        
        <a *ngIf="isAdmin()" [routerLink]="['/dashboard/forms', tableName]" 
           class="bg-blue-600 text-white px-4 py-2 rounded shadow hover:bg-blue-700 transition flex items-center gap-2">
           <span>+ Add New</span>
        </a>
      </div>
      
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th *ngFor="let col of columns" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ col.replace('_', ' ') }}
              </th>
              <th *ngIf="isAdmin()" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr *ngFor="let row of data" class="hover:bg-gray-50 transition">
              <td *ngFor="let col of columns" class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ row[col] }}
              </td>
              <td *ngIf="isAdmin()" class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button (click)="deleteItem(row)" class="text-red-600 hover:text-red-900 ml-4">Delete</button>
              </td>
            </tr>
            <tr *ngIf="data.length === 0">
                <td [attr.colspan]="columns.length + 1" class="px-6 py-8 text-center text-gray-500">
                    No data available.
                </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class GenericReportComponent implements OnInit {
  tableName = '';
  data: any[] = [];
  columns: string[] = [];
  conf: any = {};

  apiService = inject(ApiService);
  authService = inject(AuthService);
  route = inject(ActivatedRoute);

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.tableName = params.get('table') || '';
      this.conf = ENTITY_METADATA[this.tableName];
      if (this.tableName) {
        this.loadData();
      }
    });
  }

  loadData() {
    this.apiService.getAll(this.tableName).subscribe({
      next: (res) => {
        this.data = res;
        if (res.length > 0) {
          this.columns = Object.keys(res[0]);
        } else {
          // If no data, we should ideally fetch schema to get columns, but for now let's leave empty
          // or trigger a schema fetch if we really want headers.
          this.fetchSchemaForHeaders();
        }
      },
      error: (err) => console.error(err)
    });
  }

  fetchSchemaForHeaders() {
    this.apiService.getSchema(this.tableName).subscribe(schema => {
      this.columns = schema.map(f => f.column_name);
    });
  }

  deleteItem(row: any) {
    if (!confirm('Are you sure you want to delete this item?')) return;

    // Heuristic to find ID: try 'ID', 'id', or the first column
    const idKey = Object.keys(row).find(k => k.toLowerCase() === 'id') || Object.keys(row)[0];
    const id = row[idKey];

    this.apiService.delete(this.tableName, id).subscribe({
      next: () => {
        this.data = this.data.filter(item => item !== row);
      },
      error: (err) => alert('Failed to delete: ' + err.error.message)
    });
  }

  isAdmin() {
    return this.authService.currentUser()?.role === 'Admin';
  }
}
