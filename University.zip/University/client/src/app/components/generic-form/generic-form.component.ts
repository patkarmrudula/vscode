import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { ENTITY_METADATA } from '../../config/entity-metadata';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-generic-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto mt-6">
      <h2 class="text-2xl font-bold mb-6 text-gray-800">{{ isEdit ? 'Edit' : 'Add' }} {{ conf?.label || tableName | titlecase }}</h2>
      
      <form (ngSubmit)="onSubmit()" *ngIf="fields.length > 0; else loading">
        <div class="grid grid-cols-1 gap-6">
          <div *ngFor="let field of fields">
            <label [for]="field.column_name" class="block text-sm font-medium text-gray-700 mb-1 capitalize">
              {{ field.label || field.column_name.replace('_', ' ') }}
            </label>
            
            <ng-container [ngSwitch]="true">
              <!-- Select Input (Foreign Key or Options) -->
               <select *ngSwitchCase="field.type === 'select'"
                  [id]="field.column_name" [name]="field.column_name"
                  [(ngModel)]="data[field.column_name]"
                  class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white"
                  [required]="field.is_nullable === 'NO' || field.required">
                  <option [ngValue]="undefined" disabled>Select {{ field.label }}</option>
                  
                  <!-- Static Options -->
                  <ng-container *ngIf="field.options">
                      <option *ngFor="let opt of field.options" [value]="opt">{{ opt }}</option>
                  </ng-container>

                  <!-- Dynamic Source Options -->
                  <ng-container *ngIf="field.source">
                      <option *ngFor="let opt of options[field.source]" [value]="opt[field.valueField]">
                          {{ opt[field.labelField] }} {{ field.valueField !== field.labelField ? '(' + opt[field.valueField] + ')' : '' }}
                      </option>
                  </ng-container>
               </select>

              <!-- Number Input -->
              <input *ngSwitchCase="field.data_type === 'numeric' || field.data_type === 'integer' || field.type === 'number'" 
                type="number" [id]="field.column_name" [name]="field.column_name" 
                [(ngModel)]="data[field.column_name]" 
                class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                [required]="field.is_nullable === 'NO' || field.required">

              <!-- Text Input (Default) -->
              <input *ngSwitchDefault 
                type="text" [id]="field.column_name" [name]="field.column_name" 
                [(ngModel)]="data[field.column_name]" 
                class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                [required]="field.is_nullable === 'NO' || field.required">
            </ng-container>
          </div>
        </div>

        <div class="mt-8 flex justify-end">
          <button type="button" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-md mr-4 hover:bg-gray-300">Cancel</button>
          <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors">
            {{ isEdit ? 'Update' : 'Create' }}
          </button>
        </div>
      </form>
      
      <ng-template #loading>
        <div class="text-center py-8 text-gray-500">Loading form definition...</div>
      </ng-template>
    </div>
  `
})
export class GenericFormComponent implements OnInit {
  tableName = '';
  fields: any[] = [];
  data: any = {};
  isEdit = false;
  currentId: string | null = null;
  conf: any = {};
  options: any = {}; // Stores loaded options for select fields

  apiService = inject(ApiService);
  route = inject(ActivatedRoute);

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.tableName = params.get('table') || '';
      this.conf = ENTITY_METADATA[this.tableName];
      this.data = {}; // Reset data

      const id = params.get('id');
      if (id) {
        this.isEdit = true;
        this.currentId = id;
        this.loadRecord(id);
      } else {
        this.isEdit = false;
        this.currentId = null;
      }

      if (this.tableName) {
        this.loadSchema();
      }
    });
  }

  loadRecord(id: string) {
    this.apiService.getById(this.tableName, id).subscribe({
      next: (res) => this.data = res,
      error: (err) => alert('Error loading record: ' + err.error.message)
    });
  }

  loadSchema() {
    this.apiService.getSchema(this.tableName).subscribe({
      next: (schema) => {
        // Merge Schema with Metadata Config
        if (this.conf && this.conf.fields) {
          this.fields = schema.map(col => {
            const meta = this.conf.fields.find((f: any) => f.name === col.column_name);
            return meta ? { ...col, ...meta } : col;
          });
        } else {
          this.fields = schema;
        }

        this.loadOptions();
      },
      error: (err) => console.error(err)
    });
  }

  loadOptions() {
    // Find fields that need options from DB
    this.fields.forEach(field => {
      if (field.type === 'select' && field.source && !this.options[field.source]) {
        this.apiService.getAll(field.source).subscribe(res => {
          this.options[field.source] = res;
        });
      }
    });
  }

  onSubmit() {
    if (this.isEdit && this.currentId) {
      this.apiService.update(this.tableName, this.currentId, this.data).subscribe({
        next: (res) => alert('Updated successfully'),
        error: (err) => alert('Error updating: ' + (err.error.error || err.error.message))
      });
    } else {
      this.apiService.create(this.tableName, this.data).subscribe({
        next: (res) => {
          alert('Saved successfully');
          this.data = {}; // Reset
        },
        error: (err) => alert('Error saving: ' + err.error.message)
      });
    }
  }
}
