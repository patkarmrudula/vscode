export const ENTITY_METADATA: any = {
    department: {
        label: 'Department',
        pk: 'dept_name',
        fields: [
            { name: 'dept_name', label: 'Name', type: 'text', required: true },
            { name: 'building', label: 'Building', type: 'text' },
            { name: 'budget', label: 'Budget', type: 'number' }
        ]
    },
    course: {
        label: 'Course',
        pk: 'course_id',
        fields: [
            { name: 'course_id', label: 'Course ID', type: 'text', required: true },
            { name: 'title', label: 'Title', type: 'text', required: true },
            { name: 'dept_name', label: 'Department', type: 'select', source: 'department', labelField: 'dept_name', valueField: 'dept_name' },
            { name: 'credits', label: 'Credits', type: 'number' }
        ]
    },
    instructor: {
        label: 'Instructor',
        pk: 'ID',
        fields: [
            { name: 'ID', label: 'ID', type: 'text', required: true },
            { name: 'name', label: 'Name', type: 'text', required: true },
            { name: 'dept_name', label: 'Department', type: 'select', source: 'department', labelField: 'dept_name', valueField: 'dept_name' },
            { name: 'salary', label: 'Salary', type: 'number' }
        ]
    },
    student: {
        label: 'Student',
        pk: 'ID',
        fields: [
            { name: 'ID', label: 'ID', type: 'text', required: true },
            { name: 'name', label: 'Name', type: 'text', required: true },
            { name: 'dept_name', label: 'Department', type: 'select', source: 'department', labelField: 'dept_name', valueField: 'dept_name' },
            { name: 'tot_cred', label: 'Total Credits', type: 'number' }
        ]
    },
    section: {
        label: 'Section',
        pk: 'course_id', // Composite PK handling might need improvement
        fields: [
            { name: 'course_id', label: 'Course', type: 'select', source: 'course', labelField: 'title', valueField: 'course_id' },
            { name: 'sec_id', label: 'Section ID', type: 'text', required: true },
            { name: 'semester', label: 'Semester', type: 'select', options: ['Fall', 'Winter', 'Spring', 'Summer'] },
            { name: 'year', label: 'Year', type: 'number' },
            { name: 'building', label: 'Building', type: 'text' }, // Could be select from classroom
            { name: 'room_number', label: 'Room Number', type: 'text' }, // Linked to building
            { name: 'time_slot_id', label: 'Time Slot', type: 'text' }
        ]
    },
    classroom: {
        label: 'Classroom',
        pk: 'room_number',
        fields: [
            { name: 'building', label: 'Building', type: 'text', required: true },
            { name: 'room_number', label: 'Room Number', type: 'text', required: true },
            { name: 'capacity', label: 'Capacity', type: 'number' }
        ]
    }
};
