import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
    providedIn: 'root'
})
export class ApiService {
    private apiUrl = 'http://localhost:3000/api';

    constructor(private http: HttpClient, private authService: AuthService) { }

    private getHeaders() {
        const token = this.authService.getToken();
        return new HttpHeaders().set('Authorization', `Bearer ${token}`);
    }

    getAll(table: string) {
        return this.http.get<any[]>(`${this.apiUrl}/${table}`, { headers: this.getHeaders() });
    }

    getById(table: string, id: string) {
        return this.http.get<any>(`${this.apiUrl}/${table}/${id}`, { headers: this.getHeaders() });
    }

    create(table: string, data: any) {
        return this.http.post<any>(`${this.apiUrl}/${table}`, data, { headers: this.getHeaders() });
    }

    update(table: string, id: string, data: any) {
        return this.http.put<any>(`${this.apiUrl}/${table}/${id}`, data, { headers: this.getHeaders() });
    }

    delete(table: string, id: string) {
        return this.http.delete<any>(`${this.apiUrl}/${table}/${id}`, { headers: this.getHeaders() });
    }

    getSchema(table: string) {
        return this.http.get<any[]>(`${this.apiUrl}/${table}/schema`, { headers: this.getHeaders() });
    }
}
