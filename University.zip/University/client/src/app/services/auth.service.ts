import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private apiUrl = 'http://localhost:3000/api/auth';
    private tokenKey = 'auth_token';

    // Signals for reactive state
    currentUser = signal<{ username: string, role: string } | null>(null);
    isAuthenticated = signal<boolean>(false);

    constructor(private http: HttpClient, private router: Router) {
        this.checkToken();
    }

    checkToken() {
        const token = localStorage.getItem(this.tokenKey);
        if (token) {
            // Decode token to get user info (simplified, should use jwt-decode in real app)
            // For now, let's assume valid if present (server validates)
            // We stored role and username in localStorage at login too? Or just decode.
            // Let's store user info in localStorage for simplicity
            const user = JSON.parse(localStorage.getItem('user_info') || 'null');
            if (user) {
                this.currentUser.set(user);
                this.isAuthenticated.set(true);
            }
        }
    }

    login(credentials: any) {
        return this.http.post<any>(`${this.apiUrl}/login`, credentials).pipe(
            tap(response => {
                localStorage.setItem(this.tokenKey, response.token);
                const user = { username: response.username, role: response.role, linked_id: response.linked_id };
                localStorage.setItem('user_info', JSON.stringify(user));
                this.currentUser.set(user);
                this.isAuthenticated.set(true);
                this.router.navigate(['/dashboard']);
            })
        );
    }

    logout() {
        localStorage.removeItem(this.tokenKey);
        localStorage.removeItem('user_info');
        this.currentUser.set(null);
        this.isAuthenticated.set(false);
        this.router.navigate(['/login']);
    }

    getToken() {
        return localStorage.getItem(this.tokenKey);
    }
}
