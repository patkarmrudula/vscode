import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { GenericReportComponent } from './components/generic-report/generic-report.component';
import { GenericFormComponent } from './components/generic-form/generic-form.component';
import { inject } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';

const authGuard = () => {
    const auth = inject(AuthService);
    const router = inject(Router);
    if (auth.isAuthenticated()) {
        return true;
    }
    return router.parseUrl('/login');
};

export const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [authGuard],
        children: [
            { path: 'reports/:table', component: GenericReportComponent },
            { path: 'forms/:table', component: GenericFormComponent },
            { path: 'forms/:table/edit/:id', component: GenericFormComponent }, // Added Edit Route

            // Shortcuts
            { path: 'students', redirectTo: 'reports/student' },
            { path: 'courses', redirectTo: 'reports/course' },
            { path: 'instructors', redirectTo: 'reports/instructor' },
            { path: 'departments', redirectTo: 'reports/department' },
            { path: '', redirectTo: 'reports/student', pathMatch: 'full' }
        ]
    }
];
