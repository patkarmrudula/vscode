const { Client } = require('pg');

const config = {
    user: '23510082',
    password: 'Mrudula@6',
    host: 'localhost',
    port: 5432,
    database: 'university',
};

async function seedData() {
    const client = new Client(config);
    try {
        await client.connect();

        console.log("Seeding data...");

        // Clear existing data (order matters due to FKs)
        await client.query('TRUNCATE TABLE takes, teaches, section, course, student, instructor, department, classroom, users CASCADE');

        // 1. Departments
        const depts = [
            `('Biology', 'Watson', 90000)`,
            `('Comp. Sci.', 'Taylor', 100000)`,
            `('Elec. Eng.', 'Taylor', 85000)`,
            `('Finance', 'Painter', 120000)`,
            `('History', 'Painter', 50000)`,
            `('Music', 'Packard', 80000)`,
            `('Physics', 'Watson', 70000)`
        ];
        await client.query(`INSERT INTO department (dept_name, building, budget) VALUES ${depts.join(', ')}`);

        // 2. Instructors
        const instructors = [
            `('10101', 'Srinivasan', 'Comp. Sci.', 65000)`,
            `('12121', 'Wu', 'Finance', 90000)`,
            `('15151', 'Mozart', 'Music', 40000)`,
            `('22222', 'Einstein', 'Physics', 95000)`,
            `('32343', 'El Said', 'History', 60000)`,
            `('33456', 'Gold', 'Physics', 87000)`,
            `('45565', 'Katz', 'Comp. Sci.', 75000)`,
            `('58583', 'Califieri', 'History', 62000)`,
            `('76543', 'Singh', 'Finance', 80000)`,
            `('76766', 'Crick', 'Biology', 72000)`,
            `('83821', 'Brandt', 'Comp. Sci.', 92000)`,
            `('98345', 'Kim', 'Elec. Eng.', 80000)`
        ];
        await client.query(`INSERT INTO instructor (ID, name, dept_name, salary) VALUES ${instructors.join(', ')}`);

        // 3. Courses
        const courses = [
            `('BIO-101', 'Intro. to Biology', 'Biology', 4)`,
            `('BIO-301', 'Genetics', 'Biology', 4)`,
            `('BIO-399', 'Computational Biology', 'Biology', 3)`,
            `('CS-101', 'Intro. to Computer Science', 'Comp. Sci.', 4)`,
            `('CS-190', 'Game Design', 'Comp. Sci.', 4)`,
            `('CS-315', 'Robotics', 'Comp. Sci.', 3)`,
            `('CS-319', 'Image Processing', 'Comp. Sci.', 3)`,
            `('CS-347', 'Database System Concepts', 'Comp. Sci.', 3)`,
            `('EE-181', 'Intro. to Digital Systems', 'Elec. Eng.', 3)`,
            `('FIN-201', 'Investment Banking', 'Finance', 3)`,
            `('HIS-351', 'World History', 'History', 3)`,
            `('MU-199', 'Music Video Production', 'Music', 3)`,
            `('PHY-101', 'Physical Principles', 'Physics', 4)`
        ];
        await client.query(`INSERT INTO course (course_id, title, dept_name, credits) VALUES ${courses.join(', ')}`);

        // 4. Students
        const students = [
            `('00128', 'Zhang', 'Comp. Sci.', 102)`,
            `('12345', 'Shankar', 'Comp. Sci.', 32)`,
            `('19991', 'Brandt', 'History', 80)`,
            `('23121', 'Chavez', 'Finance', 110)`,
            `('44553', 'Peltier', 'Physics', 56)`,
            `('45678', 'Levy', 'Physics', 46)`,
            `('54321', 'Williams', 'Comp. Sci.', 54)`,
            `('55739', 'Sanchez', 'Music', 38)`,
            `('70557', 'Snow', 'Physics', 0)`,
            `('76543', 'Brown', 'Comp. Sci.', 58)`,
            `('76653', 'Aoi', 'Elec. Eng.', 60)`,
            `('98765', 'Bourikas', 'Elec. Eng.', 98)`,
            `('98988', 'Tanaka', 'Biology', 120)`
        ];
        await client.query(`INSERT INTO student (ID, name, dept_name, tot_cred) VALUES ${students.join(', ')}`);

        // 5. Users (Admin and Student)
        // Creating a student user linked to ID 12345 (Shankar) for testing
        // Creating an Admin
        const users = [
            `('admin', 'admin123', 'Admin')`,
            `('student1', 'student123', 'Student')`, // We'll assume this maps to 12345 logically
            `('shankar', 'shankar123', 'Student')`,
            `('zhang', 'zhang123', 'Student')`
        ];
        await client.query(`INSERT INTO users (username, password_hash, role) VALUES ${users.join(', ')} ON CONFLICT (username) DO NOTHING`);

        console.log("Seeding completed successfully.");

    } catch (err) {
        console.error('Error seeding data:', err);
    } finally {
        await client.end();
    }
}

seedData();
