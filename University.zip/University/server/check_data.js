const { Client } = require('pg');

const config = {
    user: '23510082',
    password: 'Mrudula@6',
    host: 'localhost',
    port: 5432,
    database: 'university',
};

async function checkData() {
    const client = new Client(config);
    try {
        await client.connect();

        console.log('--- Users Check ---');
        const userRes = await client.query("SELECT * FROM users WHERE username = 'student1'");
        console.log('Student User:', userRes.rows[0]);

        if (userRes.rows.length > 0 && userRes.rows[0].linked_id) {
            console.log('\n--- Linked Student Check ---');
            const studentId = userRes.rows[0].linked_id;
            const studentRes = await client.query("SELECT * FROM student WHERE ID = $1", [studentId]);
            console.log('Student Record:', studentRes.rows[0]);
        } else {
            console.log('No linked_id found for student1');
        }

    } catch (err) {
        console.error('Error:', err);
    } finally {
        await client.end();
    }
}

checkData();
