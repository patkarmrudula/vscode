const { Client } = require('pg');

const config = {
    user: '23510082',
    password: 'Mrudula@6',
    host: 'localhost',
    port: 5432,
    database: 'university',
};

async function linkStudent() {
    const client = new Client(config);
    try {
        await client.connect();

        // 1. Add linked_id column to users if not exists
        await client.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS linked_id varchar(10)`);
        console.log("Added column linked_id to users.");

        // 2. Link 'student1' to '12345' (Shankar)
        await client.query(`UPDATE users SET linked_id = '12345' WHERE username = 'student1'`);
        console.log("Linked student1 to ID 12345.");

        // 3. Link 'admin' (ensure null if we want)
        // await client.query(`UPDATE users SET linked_id = NULL WHERE username = 'admin'`);

    } catch (err) {
        console.error('Error linking data:', err);
    } finally {
        await client.end();
    }
}

linkStudent();
