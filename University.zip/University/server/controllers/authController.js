const db = require('../config/db');
const jwt = require('jsonwebtoken');
const { SECRET_KEY } = require('../middleware/auth');

exports.login = async (req, res) => {
    const { username, password } = req.body;

    try {
        const result = await db.query('SELECT * FROM users WHERE username = $1', [username]);
        if (result.rows.length === 0) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        const user = result.rows[0];

        // In a real app, uses bcrypt.compare(password, user.password_hash)
        if (password !== user.password_hash) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        const token = jwt.sign({ username: user.username, role: user.role, linked_id: user.linked_id }, SECRET_KEY, { expiresIn: '1h' });
        res.json({ token, role: user.role, username: user.username, linked_id: user.linked_id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
};
