const db = require('../config/db');

// Helper to validate table names to prevent SQL injection
const ALLOWED_TABLES = [
    'classroom', 'department', 'course', 'instructor', 'section',
    'teaches', 'student', 'takes', 'advisor', 'time_slot', 'prereq', 'users'
];

const validateTable = (tableName) => {
    return ALLOWED_TABLES.includes(tableName);
};

exports.getAll = async (req, res) => {
    const { table } = req.params;
    if (!validateTable(table)) return res.status(400).json({ message: 'Invalid table name' });

    try {
        const result = await db.query(`SELECT * FROM ${table}`);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching data' });
    }
};

exports.getById = async (req, res) => {
    const { table, id } = req.params;
    if (!validateTable(table)) return res.status(400).json({ message: 'Invalid table name' });

    try {
        let pk = 'id';
        if (table === 'student' || table === 'instructor') pk = 'ID';
        if (table === 'course') pk = 'course_id';
        if (table === 'department') pk = 'dept_name';

        const result = await db.query(`SELECT * FROM ${table} WHERE ${pk} = $1`, [id]);
        if (result.rows.length === 0) return res.status(404).json({ message: 'Not found' });
        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching record' });
    }
};

exports.getSchema = async (req, res) => {
    const { table } = req.params;
    if (!validateTable(table)) return res.status(400).json({ message: 'Invalid table name' });

    try {
        const query = `
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns 
            WHERE table_name = $1 
            ORDER BY ordinal_position;
        `;
        const result = await db.query(query, [table]);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching schema' });
    }
};

exports.create = async (req, res) => {
    const { table } = req.params;
    const data = req.body;
    if (!validateTable(table)) return res.status(400).json({ message: 'Invalid table name' });

    try {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
        const columns = keys.join(', ');

        const query = `INSERT INTO ${table} (${columns}) VALUES (${placeholders}) RETURNING *`;
        const result = await db.query(query, values);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating record', error: err.message });
    }
};

exports.update = async (req, res) => {
    const { table, id } = req.params;
    const data = req.body;
    if (!validateTable(table)) return res.status(400).json({ message: 'Invalid table name' });

    try {
        let pk = 'id';
        if (table === 'student' || table === 'instructor') pk = 'ID';
        if (table === 'course') pk = 'course_id';
        if (table === 'department') pk = 'dept_name';

        // Remove PK from data to avoid updating it
        delete data[pk];

        const keys = Object.keys(data);
        const values = Object.values(data);
        if (keys.length === 0) return res.json({ message: 'No fields to update' });

        const setClause = keys.map((key, i) => `${key} = $${i + 1}`).join(', ');

        const query = `UPDATE ${table} SET ${setClause} WHERE ${pk} = $${keys.length + 1} RETURNING *`;
        const result = await db.query(query, [...values, id]);

        if (result.rows.length === 0) return res.status(404).json({ message: 'Record not found' });
        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating record', error: err.message });
    }
};

exports.delete = async (req, res) => {
    const { table, id } = req.params;
    if (!validateTable(table)) return res.status(400).json({ message: 'Invalid table name' });

    try {
        let pk = 'id';
        if (table === 'student' || table === 'instructor') pk = 'ID';
        if (table === 'course') pk = 'course_id';
        if (table === 'department') pk = 'dept_name';

        const result = await db.query(`DELETE FROM ${table} WHERE ${pk} = $1 RETURNING *`, [id]);
        if (result.rows.length === 0) return res.status(404).json({ message: 'Record not found' });
        res.json({ message: 'Record deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting record' });
    }
};
