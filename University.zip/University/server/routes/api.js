const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const genericController = require('../controllers/genericController');
const { authenticateToken } = require('../middleware/auth');

// Auth Routes
router.post('/auth/login', authController.login);

// Generic CRUD Routes
// Protected by authentication

// Specific routes MUST come before generic routes
router.get('/:table/schema', authenticateToken, genericController.getSchema);
// router.get('/:table', genericController.getAll);
router.get('/:table', authenticateToken, genericController.getAll);
router.get('/:table/:id', authenticateToken, genericController.getById);
router.post('/:table', authenticateToken, genericController.create);
router.put('/:table/:id', authenticateToken, genericController.update);
router.delete('/:table/:id', authenticateToken, genericController.delete);

module.exports = router;
