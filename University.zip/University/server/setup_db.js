const { Client } = require('pg');

const config = {
  user: '23510082',
  password: 'Mrudula@6',
  host: 'localhost',
  port: 5432,
  database: '23510082', // connect to default user db or postgres
};

async function createDatabase() {
  const client = new Client(config);
  try {
    await client.connect();
    // Check if database exists
    const res = await client.query("SELECT 1 FROM pg_database WHERE datname = 'university'");
    if (res.rowCount === 0) {
        console.log("Creating database 'university'...");
        await client.query('CREATE DATABASE university');
        console.log("Database 'university' created successfully.");
    } else {
        console.log("Database 'university' already exists.");
    }
  } catch (err) {
    if (err.code === '3D000') { // Database does not exist error, try connecting to 'postgres'
        console.log("Database '23510082' does not exist, trying 'postgres'...");
        const client2 = new Client({ ...config, database: 'postgres' });
        try {
            await client2.connect();
            const res = await client2.query("SELECT 1 FROM pg_database WHERE datname = 'university'");
            if (res.rowCount === 0) {
                console.log("Creating database 'university'...");
                await client2.query('CREATE DATABASE university');
                console.log("Database 'university' created successfully.");
            } else {
                console.log("Database 'university' already exists.");
            }
            await client2.end();
        } catch (err2) {
             console.error('Error connecting to postgres db:', err2);
        }
    } else {
        console.error('Error creating database:', err);
    }
  } finally {
    await client.end();
  }
}

async function createSchema() {
    // Connect to the new database
    const client = new Client({ ...config, database: 'university' });
    try {
        await client.connect();
        
        console.log("Creating schema...");

        // DDL from Appendix A.2
        const queries = [
            `CREATE TABLE IF NOT EXISTS classroom
            (building varchar (15),
            room_number varchar (7),
            capacity numeric (4,0),
            primary key (building, room_number))`,

            `CREATE TABLE IF NOT EXISTS department
            (dept_name varchar (20),
            building varchar (15),
            budget numeric (12,2) check (budget > 0),
            primary key (dept_name))`,

            `CREATE TABLE IF NOT EXISTS course
            (course_id varchar (8),
            title varchar (50),
            dept_name varchar (20),
            credits numeric (2,0) check (credits > 0),
            primary key (course_id),
            foreign key (dept_name) references department (dept_name) on delete set null)`,

            `CREATE TABLE IF NOT EXISTS instructor
            (ID varchar (5),
            name varchar (20) not null,
            dept_name varchar (20),
            salary numeric (8,2) check (salary > 29000),
            primary key (ID),
            foreign key (dept_name) references department (dept_name) on delete set null)`,

            `CREATE TABLE IF NOT EXISTS section
            (course_id varchar (8),
            sec_id varchar (8),
            semester varchar (6) check (semester in ('Fall', 'Winter', 'Spring', 'Summer')),
            year numeric (4,0) check (year > 1701 and year < 2100),
            building varchar (15),
            room_number varchar (7),
            time_slot_id varchar (4),
            primary key (course_id, sec_id, semester, year),
            foreign key (course_id) references course (course_id) on delete cascade,
            foreign key (building, room_number) references classroom (building, room_number) on delete set null)`,

            `CREATE TABLE IF NOT EXISTS teaches
            (ID varchar (5),
            course_id varchar (8),
            sec_id varchar (8),
            semester varchar (6),
            year numeric (4,0),
            primary key (ID, course_id, sec_id, semester, year),
            foreign key (course_id, sec_id, semester, year) references section (course_id, sec_id, semester, year) on delete cascade,
            foreign key (ID) references instructor (ID) on delete cascade)`,

            `CREATE TABLE IF NOT EXISTS student
            (ID varchar (5),
            name varchar (20) not null,
            dept_name varchar (20),
            tot_cred numeric (3,0) check (tot_cred >= 0),
            primary key (ID),
            foreign key (dept_name) references department (dept_name) on delete set null)`,

            `CREATE TABLE IF NOT EXISTS takes
            (ID varchar (5),
            course_id varchar (8),
            sec_id varchar (8),
            semester varchar (6),
            year numeric (4,0),
            grade varchar (2),
            primary key (ID, course_id, sec_id, semester, year),
            foreign key (course_id, sec_id, semester, year) references section (course_id, sec_id, semester, year) on delete cascade,
            foreign key (ID) references student (ID) on delete cascade)`,

            `CREATE TABLE IF NOT EXISTS advisor
            (s_ID varchar (5),
            i_ID varchar (5),
            primary key (s_ID),
            foreign key (i_ID) references instructor (ID) on delete set null,
            foreign key (s_ID) references student (ID) on delete cascade)`,

            `CREATE TABLE IF NOT EXISTS time_slot
            (time_slot_id varchar (4),
            day varchar (1),
            start_time time,
            end_time time,
            primary key (time_slot_id, day, start_time))`,

            `CREATE TABLE IF NOT EXISTS prereq
            (course_id varchar (8),
            prereq_id varchar (8),
            primary key (course_id, prereq_id),
            foreign key (course_id) references course (course_id) on delete cascade,
            foreign key (prereq_id) references course (course_id))`,
            
            // Users table for Authentication
            `CREATE TABLE IF NOT EXISTS users
            (username varchar(50) PRIMARY KEY,
            password_hash varchar(255) NOT NULL,
            role varchar(20) NOT NULL CHECK (role IN ('Admin', 'Instructor', 'Student', 'Staff')))`
        ];

        for (const query of queries) {
            await client.query(query);
        }
        console.log("Schema created successfully.");

        // Insert Default Admin
        // Password: 'admin' (hashed generic placeholder or plain for now, ideally hashed)
        // For simplicity in setup, let's store plain for a sec or use a simple hash if we had bcrypt.
        // We will just insert a dummy user.
        await client.query(`INSERT INTO users (username, password_hash, role) VALUES ('admin', 'admin123', 'Admin') ON CONFLICT DO NOTHING`);
        console.log("Default admin user created.");

    } catch (err) {
        console.error('Error creating schema:', err);
    } finally {
        await client.end();
    }
}

// Run
createDatabase().then(() => createSchema());
