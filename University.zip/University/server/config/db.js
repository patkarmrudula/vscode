const { Pool } = require('pg');

const pool = new Pool({
    user: '23510082',
    password: 'Mrudula@6',
    host: 'localhost',
    port: 5432,
    database: 'university',
});

module.exports = {
    query: (text, params) => pool.query(text, params),
};
