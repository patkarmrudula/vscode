const { Client } = require('pg');

const config = {
    user: '23510082',
    password: 'Mrudula@6',
    host: 'localhost',
    port: 5432,
    database: 'university',
};

async function fixData() {
    const client = new Client(config);
    try {
        await client.connect();

        // 1. Get a valid student ID
        const studentRes = await client.query("SELECT ID, name FROM student LIMIT 1");
        if (studentRes.rows.length === 0) {
            console.log('No students found! Seeding one...');
            await client.query("INSERT INTO student (ID, name, dept_name, tot_cred) VALUES ('12345', 'Shankar', 'Comp. Sci.', 32)");
            console.log('Created student Shankar (12345)');
        }

        const validID = studentRes.rows.length > 0 ? studentRes.rows[0].id : '12345';
        console.log('Using Valid Student ID:', validID);

        // 2. Link 'student1' to this ID
        await client.query("UPDATE users SET linked_id = $1 WHERE username = 'student1'", [validID]);
        console.log(`Linked student1 to ${validID}`);

    } catch (err) {
        console.error('Error:', err);
    } finally {
        await client.end();
    }
}

fixData();
